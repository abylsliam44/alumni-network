// Futuristic v2 — Profile as orbital career system
function FxProfile() {
  return (
    <div className="aitu fx" data-screen-label="FX · Profile">
      <div className="hud-corners"><i></i></div>
      <FxRail active="home" />
      <div className="stage" style={{ position: "relative" }}>
        <FxTopbar coords="PROFILE · MADIYAR_TOLEU · ALUMNI '18" sess="0xPF-883C" />

        <div className="body" style={{ flexDirection: "column", overflow: "hidden" }}>
          <div style={{ flex: 1, overflow: "hidden", position: "relative", display: "grid",
                        gridTemplateColumns: "360px 1fr", gap: 0 }}>

            {/* Left identity column */}
            <div style={{ padding: "28px 26px", borderRight: "1px solid var(--line-soft)",
                          background: "linear-gradient(180deg, rgba(15,18,22,0.6), transparent 60%)",
                          overflowY: "auto" }}>
              <div className="tele">[ ID · 0x4F2A · VERIFIED ]</div>
              <div style={{ width: 120, height: 120, borderRadius: 22, marginTop: 16,
                            background: "linear-gradient(135deg, #3a3a48, #1f1f28)",
                            color: "#d6d2c2", display: "grid", placeItems: "center",
                            fontFamily: "var(--mono)", fontSize: 38, fontWeight: 600,
                            boxShadow: "0 0 32px -8px rgba(75,166,220,0.4)" }}>
                MT
              </div>

              <div className="mega" style={{ fontSize: 44, marginTop: 18, lineHeight: 1.05 }}>
                Madiyar<br/>Toleu<span style={{ color: "var(--blue)" }}>.</span>
              </div>
              <div className="tele" style={{ marginTop: 10, lineHeight: 1.7 }}>
                SR. SOFTWARE ENG · KASPI.KZ<br/>
                ALMATY · KZ · CLASS '18
              </div>

              <div style={{ display: "flex", flexWrap: "wrap", gap: 6, marginTop: 14 }}>
                <Pill tone="blue" dot>Mentor · accepting</Pill>
                <Pill tone="ok" dot>Verified resume</Pill>
              </div>

              <div style={{ marginTop: 18, padding: "14px 16px", border: "1px solid var(--blue-line)", borderRadius: 12, background: "rgba(75,166,220,0.05)" }}>
                <div className="tele">MENTORSHIP CAPACITY</div>
                <div style={{ display: "flex", alignItems: "baseline", gap: 8, marginTop: 6 }}>
                  <span className="mega-mono" style={{ fontSize: 36 }}>04</span>
                  <span className="tele">/ 06 · 2 OPEN</span>
                </div>
                <div style={{ display: "grid", gridTemplateColumns: "repeat(6,1fr)", gap: 4, marginTop: 10 }}>
                  {Array.from({ length: 6 }).map((_, i) => (
                    <div key={i} style={{ height: 22, borderRadius: 4, background: i < 4 ? "var(--blue)" : "transparent", border: "1px solid " + (i < 4 ? "var(--blue)" : "var(--line)"), boxShadow: i < 4 ? "0 0 10px -2px var(--blue)" : "none" }} />
                  ))}
                </div>
              </div>

              <div className="tele" style={{ margin: "20px 0 8px" }}>HELPS WITH</div>
              <div style={{ display: "flex", flexWrap: "wrap", gap: 5 }}>
                {["Backend", "Distributed sys", "Career", "Interview prep", "JVM"].map(s => (
                  <span key={s} className="chip skill">{s}</span>
                ))}
              </div>

              <div className="tele" style={{ margin: "20px 0 8px" }}>★ 4.9 · 32 MENTEES</div>
              <div className="serif" style={{ fontSize: 16, lineHeight: 1.4, color: "var(--ink)" }}>
                "Pushed me to ship a real distributed system in 8 weeks. I now lead infra."
              </div>
              <div className="tele" style={{ marginTop: 8 }}>— ASEM K. · 2025</div>

              <div style={{ display: "flex", gap: 6, marginTop: 22 }}>
                <button className="btn" style={{ flex: 1, justifyContent: "center" }}>Message</button>
                <button className="btn primary" style={{ flex: 2, justifyContent: "center" }}>Request mentorship ↗</button>
              </div>
            </div>

            {/* Right — orbital career system */}
            <div style={{ position: "relative", overflow: "hidden" }}>
              <div style={{ position: "absolute", top: 24, left: 28, zIndex: 2 }}>
                <div className="tele">[ TRAJECTORY · 7 YEARS · 4 NODES ]</div>
                <div className="mega" style={{ fontSize: 44, marginTop: 6 }}>
                  AITU → <span style={{ color: "var(--blue)" }}>principal-track</span>.
                </div>
              </div>

              <div style={{ position: "absolute", top: 24, right: 28, zIndex: 2, textAlign: "right" }}>
                <div className="tele">DRAG · ORBIT</div>
                <div style={{ display: "flex", gap: 4, marginTop: 6, justifyContent: "flex-end" }}>
                  <Pill>2014—2026</Pill>
                  <Pill tone="blue" dot>Now</Pill>
                </div>
              </div>

              <Orbit />

              {/* bottom timeline strip */}
              <div style={{ position: "absolute", bottom: 0, left: 0, right: 0, padding: "14px 28px",
                            borderTop: "1px solid var(--line-soft)", background: "rgba(8,10,12,0.7)" }}>
                <div style={{ display: "grid", gridTemplateColumns: "repeat(4,1fr)", gap: 14 }}>
                  {[
                    { y: "2014—18", t: "AITU · BSc SE", co: "EDUCATION", c: "var(--warm)" },
                    { y: "2019—20", t: "Higgsfield · Intern", co: "FIRST JOB", c: "var(--blue)" },
                    { y: "2020—23", t: "Beeline KZ · SWE", co: "EMPLOYMENT", c: "var(--blue)" },
                    { y: "2023—NOW", t: "Kaspi · Senior SWE", co: "CURRENT · MENTOR", c: "var(--ok)", live: true },
                  ].map((s, i) => (
                    <div key={i} style={{ borderLeft: `2px solid ${s.c}`, paddingLeft: 12 }}>
                      <div className="tele" style={{ color: s.c }}>{s.live && <span className="pulse-dot ok" />} {s.live && " "}{s.co}</div>
                      <div style={{ fontSize: 13, color: "var(--ink)", marginTop: 4 }}>{s.t}</div>
                      <div className="tele" style={{ marginTop: 2 }}>{s.y}</div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// Orbital career — concentric rings, each role is a planet on its orbit
function Orbit() {
  const W = 900, H = 720;
  const cx = W / 2, cy = H / 2 + 30;
  // 5 orbits — first job innermost, current outermost (or by time)
  const planets = [
    { name: "AITU · BSc SE", years: "2014—2018", radius: 110, angle: -110, size: 14, color: "#d8a574", track: "education" },
    { name: "Higgsfield · Intern", years: "2019—2020", radius: 175, angle: -50, size: 10, color: "#4ba6dc", track: "employment" },
    { name: "kafka-trace · OSS", years: "2021—2022", radius: 215, angle: 40, size: 8, color: "#6e695e", track: "project" },
    { name: "Beeline · SWE", years: "2020—2023", radius: 250, angle: 110, size: 14, color: "#4ba6dc", track: "employment" },
    { name: "AWS Cert", years: "2022", radius: 210, angle: -160, size: 7, color: "#d8a574", track: "education" },
    { name: "AITU mentor", years: "2022—now", radius: 290, angle: -75, size: 10, color: "#6db38c", track: "mentorship", current: true },
    { name: "qdrant-pgsync", years: "2024", radius: 280, angle: 165, size: 8, color: "#6e695e", track: "project" },
    { name: "Kaspi · Senior", years: "2023—NOW", radius: 330, angle: 0, size: 18, color: "#4ba6dc", track: "employment", current: true },
  ];
  return (
    <svg viewBox={`0 0 ${W} ${H}`} width="100%" height="100%" style={{ position: "absolute", inset: 0 }}>
      <defs>
        <radialGradient id="centerGlow" cx="50%" cy="50%" r="50%">
          <stop offset="0%" stopColor="#d8a574" stopOpacity="0.5" />
          <stop offset="100%" stopColor="#d8a574" stopOpacity="0" />
        </radialGradient>
        <linearGradient id="orbitFade" x1="0" x2="1">
          <stop offset="0%" stopColor="rgba(75,166,220,0.0)" />
          <stop offset="50%" stopColor="rgba(75,166,220,0.35)" />
          <stop offset="100%" stopColor="rgba(75,166,220,0.0)" />
        </linearGradient>
      </defs>
      {/* concentric orbits */}
      {[110, 175, 215, 250, 290, 330].map((r, i) => (
        <circle key={i} cx={cx} cy={cy} r={r} fill="none" stroke="var(--line)" strokeDasharray="1 4" />
      ))}
      {/* swept arc on outer */}
      <path d={`M ${cx - 330} ${cy} A 330 330 0 0 1 ${cx + 330} ${cy}`} fill="none" stroke="url(#orbitFade)" strokeWidth="1.5" />
      <circle cx={cx} cy={cy} r={50} fill="url(#centerGlow)" />
      <circle cx={cx} cy={cy} r={14} fill="var(--warm)" />
      <circle cx={cx} cy={cy} r={26} fill="none" stroke="var(--warm)" strokeOpacity="0.4" />
      <text x={cx} y={cy + 4} fill="#1a1410" fontFamily="var(--mono)" fontSize="9" fontWeight="700" textAnchor="middle">2018</text>
      <text x={cx} y={cy + 48} fill="var(--warm)" fontFamily="var(--mono)" fontSize="9" textAnchor="middle">▼ ORIGIN · AITU GRAD</text>

      {planets.map((p, i) => {
        const a = (p.angle * Math.PI) / 180;
        const x = cx + Math.cos(a) * p.radius;
        const y = cy + Math.sin(a) * p.radius;
        const labelLeft = x < cx;
        return (
          <g key={i}>
            {/* trail */}
            <line x1={cx} y1={cy} x2={x} y2={y} stroke={p.color} strokeOpacity="0.15" strokeDasharray="1 2" />
            <circle cx={x} cy={y} r={p.size} fill={p.color} />
            {p.current && <circle cx={x} cy={y} r={p.size + 6} fill="none" stroke={p.color} strokeOpacity="0.5" />}
            {p.current && <circle cx={x} cy={y} r={p.size + 11} fill="none" stroke={p.color} strokeOpacity="0.25" />}
            <line
              x1={x + (labelLeft ? -p.size - 2 : p.size + 2)}
              y1={y}
              x2={x + (labelLeft ? -p.size - 18 : p.size + 18)}
              y2={y}
              stroke={p.color}
              strokeOpacity="0.5"
            />
            <text x={x + (labelLeft ? -p.size - 22 : p.size + 22)} y={y - 2}
                  fill="var(--ink)" fontFamily="var(--sans)" fontSize="11.5"
                  textAnchor={labelLeft ? "end" : "start"}>
              {p.name}
            </text>
            <text x={x + (labelLeft ? -p.size - 22 : p.size + 22)} y={y + 11}
                  fill="var(--ink-3)" fontFamily="var(--mono)" fontSize="9"
                  textAnchor={labelLeft ? "end" : "start"}>
              {p.years} · {p.track.toUpperCase()}
            </text>
          </g>
        );
      })}
    </svg>
  );
}

window.FxProfile = FxProfile;
