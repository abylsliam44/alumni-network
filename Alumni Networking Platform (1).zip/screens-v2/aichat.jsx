// Futuristic v2 — AqyldyAI as transmission console
function FxAiChat() {
  return (
    <div className="aitu fx" data-screen-label="FX · AqyldyAI">
      <div className="hud-corners"><i></i></div>
      <FxRail active="ai" />
      <div className="stage" style={{ position: "relative" }}>
        <FxTopbar coords="AQYLDY · ORACLE_CHANNEL" sess="0xAI-2026" />
        <div className="body" style={{ flexDirection: "column", overflow: "hidden", position: "relative" }}>

          {/* Ambient orbs */}
          <div style={{ position: "absolute", top: -40, right: -40, width: 360, height: 360, borderRadius: "50%",
                        background: "radial-gradient(circle, rgba(75,166,220,0.18), transparent 60%)",
                        pointerEvents: "none" }} />
          <div style={{ position: "absolute", bottom: -80, left: -40, width: 300, height: 300, borderRadius: "50%",
                        background: "radial-gradient(circle, rgba(216,165,116,0.12), transparent 60%)",
                        pointerEvents: "none" }} />

          {/* Header */}
          <div style={{ padding: "32px 64px 16px", display: "grid", gridTemplateColumns: "auto 1fr auto", gap: 24, alignItems: "center", position: "relative", zIndex: 1 }}>
            <div style={{ position: "relative", width: 76, height: 76 }}>
              <div style={{ position: "absolute", inset: 0, borderRadius: "50%",
                            background: "radial-gradient(circle, rgba(75,166,220,0.35), transparent 70%)",
                            filter: "blur(2px)" }} />
              <div style={{ position: "absolute", inset: 0, display: "grid", placeItems: "center" }}>
                <AituGlyph size={68} color="var(--ink)" accent="var(--blue)" />
              </div>
            </div>
            <div>
              <div className="tele">[ AQYLDY · ORACLE · v2.4 · CLAUDE-HAIKU 4.5 + RAG ]</div>
              <div className="mega" style={{ fontSize: 48, marginTop: 4 }}>
                Speak. <i style={{ color: "var(--blue)" }}>I see your network.</i>
              </div>
            </div>
            <div className="tele" style={{ textAlign: "right", lineHeight: 1.7 }}>
              <span className="pulse-dot ok" /> SYNCED · 4M AGO<br/>
              KB · 1,284 ALUMNI · 312 EVENTS · 78 DOCS
            </div>
          </div>

          {/* Body */}
          <div style={{ flex: 1, overflowY: "auto", padding: "16px 64px 16px", position: "relative", zIndex: 1 }}>

            {/* User msg */}
            <div style={{ display: "flex", justifyContent: "flex-end", marginBottom: 22 }}>
              <div style={{ maxWidth: 560 }}>
                <div className="tele" style={{ marginBottom: 6, textAlign: "right" }}>USER · 14:22:04 · KZ</div>
                <div style={{ padding: "14px 18px", background: "var(--surface-2)",
                              border: "1px solid var(--line)",
                              borderRadius: "16px 16px 4px 16px",
                              fontSize: 14, lineHeight: 1.5 }}>
                  Backend roles in Almaty that would actually take a Y3 AITU student with Go + a couple of side projects? Be specific — companies, not vibes.
                </div>
              </div>
            </div>

            {/* AI response */}
            <div style={{ display: "grid", gridTemplateColumns: "44px 1fr", gap: 16, marginBottom: 22 }}>
              <div style={{ width: 44, height: 44, borderRadius: 12, background: "var(--bg-2)",
                            border: "1px solid var(--blue-line)",
                            display: "grid", placeItems: "center",
                            boxShadow: "0 0 16px -4px rgba(75,166,220,0.4)" }}>
                <AituGlyph size={28} color="var(--ink-2)" accent="var(--blue)" />
              </div>
              <div>
                <div className="tele" style={{ marginBottom: 8 }}>
                  ORACLE · 14:22:07 · <b>RETRIEVED</b> 18 vectors · <b>CONFIDENCE</b> 0.91
                </div>
                <div style={{ fontSize: 14, lineHeight: 1.6, color: "var(--ink)", marginBottom: 14 }}>
                  Three companies hire Y3 students with your stack reliably — based on alumni placements over the last 18 months and current openings:
                </div>

                {/* Result cards with HUD frame */}
                <div style={{ display: "grid", gap: 10, marginBottom: 16 }}>
                  {[
                    { co: "Kaspi.kz", role: "Backend Intern · Go/Java", note: "Hired 14 AITU in 2024–25.", score: 0.94, mentor: "Madiyar T." },
                    { co: "Kolesa Group", role: "Junior Backend · Go", note: "Open to Y3 with 1 deployed project.", score: 0.91, mentor: "Asem K." },
                    { co: "BTS Digital", role: "SWE Intern · Go/Python", note: "Smallest team — fastest impact.", score: 0.84, mentor: null },
                  ].map((o, i) => (
                    <div key={i} className="glass" style={{ padding: "12px 14px", display: "grid", gridTemplateColumns: "32px 1fr auto auto", gap: 14, alignItems: "center" }}>
                      <div className="mono" style={{ fontSize: 18, color: "var(--blue)", textAlign: "center", fontWeight: 600 }}>
                        {String(i + 1).padStart(2, "0")}
                      </div>
                      <div>
                        <div style={{ fontSize: 13.5, color: "var(--ink)" }}>
                          {o.co} <span className="tele" style={{ marginLeft: 6 }}>{o.role}</span>
                        </div>
                        <div style={{ fontSize: 12, color: "var(--ink-2)", marginTop: 2 }}>
                          {o.note}{o.mentor && <> · mentor inside: <span style={{ color: "var(--blue)" }}>{o.mentor}</span></>}
                        </div>
                      </div>
                      <SimBar v={o.score} />
                      <button className="btn sm">↗</button>
                    </div>
                  ))}
                </div>

                <div style={{ fontSize: 13.5, color: "var(--ink-2)" }}>
                  Want me to <span style={{ color: "var(--blue)", borderBottom: "1px dashed var(--blue)" }}>draft a cold email to Asem</span> or build a <span style={{ color: "var(--blue)", borderBottom: "1px dashed var(--blue)" }}>72-hour prep plan</span>?
                </div>

                {/* Sources block — terminal style */}
                <div style={{ marginTop: 16, padding: "10px 14px",
                              background: "rgba(8,10,12,0.7)",
                              border: "1px dashed var(--line)", borderRadius: 8 }}>
                  <div className="tele" style={{ color: "var(--blue)", marginBottom: 4 }}>// SOURCES · 4 used</div>
                  <div className="mono" style={{ fontSize: 10.5, color: "var(--ink-3)", lineHeight: 1.7 }}>
                    [01] alumni-placements-2024.csv · 1,284 records<br/>
                    [02] jobs/open?filter=intern · 86 results<br/>
                    [03] interviews/transcripts/2025-q1 · 6 alumni<br/>
                    [04] handbook/career-services.md · v3.2
                  </div>
                </div>
              </div>
            </div>

            {/* Suggested transmissions */}
            <div className="tele" style={{ marginBottom: 8 }}>↳ SUGGESTED TRANSMISSIONS</div>
            <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
              {["Draft cold email to Asem", "72-hour prep plan", "Compare Kolesa vs Kaspi culture", "Set up resume import", "Find Almaty meetups"].map((s, i) => (
                <button key={i} className="btn sm" style={{ background: "rgba(75,166,220,0.05)", borderColor: "var(--blue-line)", color: "var(--blue)" }}>{s}</button>
              ))}
            </div>
          </div>

          {/* Composer — sci-fi */}
          <div style={{ padding: "16px 64px 24px", borderTop: "1px solid var(--line-soft)",
                        background: "rgba(8,10,12,0.6)", backdropFilter: "blur(8px)" }}>
            <div className="glass" style={{ padding: "12px 14px" }}>
              <div className="tele" style={{ marginBottom: 6 }}>// COMPOSE TRANSMISSION</div>
              <div style={{ minHeight: 48, fontSize: 14, color: "var(--ink-2)", padding: "2px 0 8px" }}>
                Ask AqyldyAI · use <span style={{ color: "var(--blue)" }}>@profile</span>, <span style={{ color: "var(--blue)" }}>@alumni</span>, <span style={{ color: "var(--blue)" }}>@jobs</span> to scope context…
                <span style={{ display: "inline-block", width: 8, height: 16, background: "var(--blue)", marginLeft: 2, verticalAlign: "text-top", animation: "pulse 1s infinite" }} />
              </div>
              <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
                <Pill tone="blue" dot>@profile</Pill>
                <Pill>@alumni</Pill>
                <button className="iconbtn"><Icon name="upload" size={14} /></button>
                <div style={{ flex: 1 }} />
                <span className="tele">⌘ + ⏎ TO TRANSMIT</span>
                <button className="btn primary sm"><Icon name="send" size={12} /> Transmit</button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
window.FxAiChat = FxAiChat;
