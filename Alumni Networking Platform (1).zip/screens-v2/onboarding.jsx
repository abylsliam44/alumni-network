// Onboarding — futuristic landing with cursor-tracking constellation
const { useEffect, useRef, useState } = React;

function Onboarding() {
  const stageRef = useRef(null);
  const [mouse, setMouse] = useState({ x: 0.5, y: 0.5, active: false });
  const [t, setT] = useState(0);

  // Smoothed pointer
  const target = useRef({ x: 0.5, y: 0.5 });
  const current = useRef({ x: 0.5, y: 0.5 });

  useEffect(() => {
    let raf;
    const tick = () => {
      current.current.x += (target.current.x - current.current.x) * 0.08;
      current.current.y += (target.current.y - current.current.y) * 0.08;
      setMouse(m => ({ ...m, x: current.current.x, y: current.current.y }));
      setT(performance.now() / 1000);
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, []);

  const onMove = (e) => {
    const r = stageRef.current.getBoundingClientRect();
    target.current = {
      x: (e.clientX - r.left) / r.width,
      y: (e.clientY - r.top) / r.height,
    };
    setMouse(m => ({ ...m, active: true }));
  };
  const onLeave = () => {
    target.current = { x: 0.5, y: 0.5 };
    setMouse(m => ({ ...m, active: false }));
  };

  // Nodes — alumni constellation
  const nodes = React.useMemo(() => {
    const seed = (i) => {
      const x = Math.sin(i * 9301 + 49297) * 233280;
      return x - Math.floor(x);
    };
    const out = [];
    const labels = [
      "Madiyar · Kaspi",
      "Asem · Kolesa",
      "Tomiris · Higgsfield",
      "Yerbol · Stripe",
      "Madina · Beeline",
      "Ruslan · Codify",
      "Dinara · Halyk",
      "Aisha · Halyk",
      "Marat · stealth",
      "Daulet · Kaspi",
    ];
    // labeled
    labels.forEach((l, i) => {
      const a = (i / labels.length) * Math.PI * 2 + 0.3;
      const r = 0.22 + seed(i) * 0.16;
      out.push({ id: "L" + i, label: l, a, r, big: true });
    });
    // ambient
    for (let i = 0; i < 90; i++) {
      const a = seed(i + 10) * Math.PI * 2;
      const r = 0.08 + seed(i + 100) * 0.45;
      out.push({ id: "a" + i, a, r, big: false, size: 0.7 + seed(i + 200) * 1.8 });
    }
    return out;
  }, []);

  const W = 1380, H = 880;
  const cx = W * 0.62;
  const cy = H * 0.55;

  // mouse pull: nodes drift toward cursor a bit
  const mx = mouse.x * W;
  const my = mouse.y * H;
  const pull = mouse.active ? 0.08 : 0;

  return (
    <div
      ref={stageRef}
      onMouseMove={onMove}
      onMouseLeave={onLeave}
      className="aitu onb"
      data-screen-label="01 Onboarding"
      style={{ position: "relative", overflow: "hidden", cursor: "none" }}
    >
      {/* deep gradient field */}
      <div style={{
        position: "absolute", inset: 0,
        background: `
          radial-gradient(900px 600px at ${mouse.x * 100}% ${mouse.y * 100}%, rgba(75,166,220,0.18), transparent 55%),
          radial-gradient(1200px 700px at 80% 30%, rgba(216,165,116,0.06), transparent 60%),
          radial-gradient(800px 800px at 20% 100%, rgba(75,166,220,0.04), transparent 60%),
          #07090b
        `,
        transition: "background 0.18s linear",
      }} />

      {/* grain + grid */}
      <div style={{
        position: "absolute", inset: 0, opacity: 0.4,
        backgroundImage:
          "linear-gradient(rgba(255,255,255,0.022) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.022) 1px, transparent 1px)",
        backgroundSize: "48px 48px",
        maskImage: "radial-gradient(ellipse at center, #000 30%, transparent 80%)",
      }} />

      {/* corner brackets */}
      <Bracket pos="tl" /><Bracket pos="tr" /><Bracket pos="bl" /><Bracket pos="br" />

      {/* HUD: top strip */}
      <div style={{ position: "absolute", top: 22, left: 28, right: 28, display: "flex", alignItems: "center", justifyContent: "space-between", zIndex: 4 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
          <AituGlyph size={28} color="#f1ede4" accent="#4ba6dc" />
          <div style={{ fontFamily: "var(--mono)", fontSize: 10.5, letterSpacing: "0.16em", color: "var(--ink-2)" }}>
            ALUMNI NETWORKING PLATFORM — <span style={{ color: "var(--blue)" }}>v2.6 · MAY 2026</span>
          </div>
        </div>
        <div style={{ display: "flex", gap: 18, fontFamily: "var(--mono)", fontSize: 10.5, color: "var(--ink-3)", letterSpacing: "0.08em" }}>
          <Live label="ALUMNI" val="1,284" />
          <Live label="MENTORS" val="134" dot />
          <Live label="OPEN ROLES" val="86" />
          <Live label="SESSION" val={`T+${Math.floor(t).toString().padStart(2, "0")}:${Math.floor((t * 6) % 60).toString().padStart(2, "0")}`} />
        </div>
      </div>

      {/* SVG constellation */}
      <svg viewBox={`0 0 ${W} ${H}`} width="100%" height="100%" style={{ position: "absolute", inset: 0, zIndex: 1 }}>
        <defs>
          <radialGradient id="coreG" cx="50%" cy="50%" r="50%">
            <stop offset="0%" stopColor="#d8a574" stopOpacity="1" />
            <stop offset="60%" stopColor="#d8a574" stopOpacity="0.2" />
            <stop offset="100%" stopColor="#d8a574" stopOpacity="0" />
          </radialGradient>
          <radialGradient id="nodeG" cx="50%" cy="50%" r="50%">
            <stop offset="0%" stopColor="#4ba6dc" stopOpacity="1" />
            <stop offset="100%" stopColor="#4ba6dc" stopOpacity="0" />
          </radialGradient>
        </defs>

        {/* orbital rings */}
        {[0.18, 0.28, 0.40].map((r, i) => (
          <ellipse key={i} cx={cx} cy={cy}
                   rx={W * r} ry={W * r * 0.55}
                   fill="none" stroke="rgba(75,166,220,0.10)"
                   strokeDasharray={i === 1 ? "0" : "2 6"}
                   transform={`rotate(${t * (i === 1 ? 4 : -3)} ${cx} ${cy})`} />
        ))}

        {/* connections from cursor */}
        {nodes.filter(n => n.big).map((n, i) => {
          const x = cx + Math.cos(n.a + t * 0.04) * (W * n.r);
          const y = cy + Math.sin(n.a + t * 0.04) * (W * n.r * 0.6);
          const dx = mx - x, dy = my - y;
          const d = Math.hypot(dx, dy);
          const near = d < 280 && mouse.active;
          return (
            <line key={i} x1={mx} y1={my} x2={x} y2={y}
                  stroke="#4ba6dc"
                  strokeOpacity={near ? Math.max(0, 0.45 - d / 700) : 0}
                  strokeWidth={near ? 0.8 : 0} />
          );
        })}

        {/* central core */}
        <circle cx={cx} cy={cy} r={70} fill="url(#coreG)" />
        <circle cx={cx} cy={cy} r={6} fill="#d8a574" />
        <circle cx={cx} cy={cy} r={12 + Math.sin(t * 2) * 2} fill="none" stroke="#d8a574" strokeOpacity="0.5" />
        <circle cx={cx} cy={cy} r={22 + Math.sin(t * 2 + 1) * 3} fill="none" stroke="#d8a574" strokeOpacity="0.2" />
        <text x={cx} y={cy - 86} textAnchor="middle" fill="#d8a574" fontFamily="var(--mono)" fontSize="10" letterSpacing="0.16em">YOU · ORIGIN</text>

        {/* nodes */}
        {nodes.map((n, i) => {
          const baseX = cx + Math.cos(n.a + t * 0.04) * (W * n.r);
          const baseY = cy + Math.sin(n.a + t * 0.04) * (W * n.r * 0.6);
          const dx = mx - baseX, dy = my - baseY;
          const d = Math.hypot(dx, dy) || 1;
          const x = baseX + (dx / d) * Math.min(40, 1200 / d) * pull;
          const y = baseY + (dy / d) * Math.min(40, 1200 / d) * pull;

          if (!n.big) {
            return (
              <circle key={i} cx={x} cy={y} r={n.size}
                      fill="#f1ede4" fillOpacity={0.45 - n.r * 0.6} />
            );
          }
          const near = Math.hypot(mx - baseX, my - baseY) < 200 && mouse.active;
          return (
            <g key={i}>
              <circle cx={x} cy={y} r={18} fill="url(#nodeG)" opacity={near ? 0.9 : 0.4} />
              <circle cx={x} cy={y} r={3.2} fill="#4ba6dc" />
              <text x={x + 10} y={y + 3} fill={near ? "#f1ede4" : "rgba(241,237,228,0.55)"}
                    fontFamily="var(--sans)" fontSize="11">{n.label}</text>
            </g>
          );
        })}

        {/* scanning ring tied to cursor */}
        {mouse.active && (
          <>
            <circle cx={mx} cy={my} r={48 + Math.sin(t * 3) * 8} fill="none" stroke="#4ba6dc" strokeOpacity="0.35" />
            <circle cx={mx} cy={my} r={86 + Math.sin(t * 3 + 1) * 12} fill="none" stroke="#4ba6dc" strokeOpacity="0.15" strokeDasharray="3 6" />
          </>
        )}
      </svg>

      {/* Custom cursor */}
      <div style={{
        position: "absolute", left: mx, top: my,
        transform: "translate(-50%, -50%)",
        pointerEvents: "none", zIndex: 6,
        opacity: mouse.active ? 1 : 0,
        transition: "opacity 0.2s",
      }}>
        <svg width="64" height="64" viewBox="0 0 64 64">
          <circle cx="32" cy="32" r="3" fill="#4ba6dc" />
          <circle cx="32" cy="32" r="12" fill="none" stroke="#4ba6dc" strokeOpacity="0.6" />
          <line x1="32" y1="2" x2="32" y2="14" stroke="#4ba6dc" />
          <line x1="32" y1="50" x2="32" y2="62" stroke="#4ba6dc" />
          <line x1="2" y1="32" x2="14" y2="32" stroke="#4ba6dc" />
          <line x1="50" y1="32" x2="62" y2="32" stroke="#4ba6dc" />
        </svg>
        <div style={{
          position: "absolute", left: 36, top: 30,
          fontFamily: "var(--mono)", fontSize: 9, color: "#4ba6dc",
          letterSpacing: "0.1em", whiteSpace: "nowrap",
        }}>
          ◉ SCANNING<br />
          <span style={{ color: "rgba(75,166,220,0.6)" }}>
            {(mouse.x * 100).toFixed(1)}, {(mouse.y * 100).toFixed(1)}
          </span>
        </div>
      </div>

      {/* Headline & CTAs */}
      <div style={{
        position: "absolute", left: 60, top: "50%",
        transform: "translateY(-50%)", zIndex: 3, maxWidth: 560,
      }}>
        <div className="eyebrow" style={{ marginBottom: 14, color: "var(--blue)" }}>
          ◉ AITU · ALUMNI NETWORKING PLATFORM
        </div>
        <div style={{
          fontFamily: "var(--sans)", fontSize: 64, lineHeight: 0.98, fontWeight: 500,
          letterSpacing: "-0.025em", marginBottom: 22, color: "var(--ink)",
        }}>
          The network<br />
          <i style={{ fontFamily: "var(--serif)", fontWeight: 400, color: "var(--blue)" }}>already knows</i><br />
          where you're going.
        </div>
        <div style={{ fontSize: 15, lineHeight: 1.55, color: "var(--ink-2)", maxWidth: 460, marginBottom: 28 }}>
          1,284 AITU alumni mapped to your skills, ambitions, and trajectory.
          Move your cursor — see who's closest.
        </div>
        <div style={{ display: "flex", gap: 10 }}>
          <button className="btn primary lg" style={{ paddingInline: 24 }}>
            Enter the network <Icon name="arrowR" size={14} />
          </button>
          <button className="btn lg" style={{ background: "rgba(255,255,255,0.03)", borderColor: "rgba(255,255,255,0.12)" }}>
            Continue with AITU SSO
          </button>
        </div>

        <div style={{ display: "flex", gap: 14, marginTop: 30, alignItems: "center" }}>
          <div style={{ display: "flex" }}>
            {["b1", "b4", "b6", "b3"].map((t, i) => (
              <div key={i} style={{ marginLeft: i ? -10 : 0, border: "2px solid #07090b", borderRadius: "50%" }}>
                <Avatar name={["MT", "AK", "TB", "RO"][i]} tone={t} size="s" />
              </div>
            ))}
          </div>
          <div className="mono" style={{ fontSize: 10.5, color: "var(--ink-3)", letterSpacing: "0.06em" }}>
            <span style={{ color: "var(--ok)" }}>● 247 ONLINE</span> · joined this week: 42
          </div>
        </div>
      </div>

      {/* Right HUD: live transmission */}
      <div style={{
        position: "absolute", right: 28, top: "50%", transform: "translateY(-50%)",
        width: 280, zIndex: 3,
      }}>
        <HudPanel title="LIVE · NEAR YOU">
          {[
            { n: "Madina A.", action: "accepted mentor request", t: "now", tone: "var(--ok)" },
            { n: "Ruslan O.", action: "opened ML intern role", t: "2m", tone: "var(--blue)" },
            { n: "Tomiris B.", action: "posted: RAG benchmarks", t: "8m", tone: "var(--ink-2)" },
            { n: "Asem K.", action: "is hiring · Kolesa", t: "11m", tone: "var(--warm)" },
          ].map((e, i) => (
            <div key={i} style={{
              padding: "10px 12px", borderTop: i ? "1px solid rgba(75,166,220,0.10)" : "none",
              display: "grid", gridTemplateColumns: "8px 1fr auto", gap: 10, alignItems: "center",
            }}>
              <span style={{ width: 6, height: 6, borderRadius: "50%", background: e.tone }} />
              <div style={{ fontSize: 11.5, color: "var(--ink-2)", lineHeight: 1.35 }}>
                <span style={{ color: "var(--ink)" }}>{e.n}</span> {e.action}
              </div>
              <span className="mono" style={{ fontSize: 9.5, color: "var(--ink-3)" }}>{e.t}</span>
            </div>
          ))}
        </HudPanel>

        <div style={{ height: 14 }} />

        <HudPanel title="◉ FIRST 3 STEPS">
          {[
            { k: "01", t: "Import your resume", st: "next" },
            { k: "02", t: "Pick 3 mentors", st: "queued" },
            { k: "03", t: "Set career intent", st: "queued" },
          ].map((s, i) => (
            <div key={i} style={{
              padding: "10px 12px", borderTop: i ? "1px solid rgba(75,166,220,0.10)" : "none",
              display: "grid", gridTemplateColumns: "auto 1fr auto", gap: 10, alignItems: "center",
            }}>
              <span className="mono" style={{ fontSize: 11, color: s.st === "next" ? "var(--blue)" : "var(--ink-4)" }}>{s.k}</span>
              <span style={{ fontSize: 12, color: s.st === "next" ? "var(--ink)" : "var(--ink-3)" }}>{s.t}</span>
              {s.st === "next" && <Icon name="arrowR" size={12} color="var(--blue)" />}
            </div>
          ))}
        </HudPanel>
      </div>

      {/* Bottom telemetry strip */}
      <div style={{
        position: "absolute", left: 28, right: 28, bottom: 22,
        display: "flex", justifyContent: "space-between", alignItems: "center",
        fontFamily: "var(--mono)", fontSize: 10, color: "var(--ink-3)",
        letterSpacing: "0.1em", zIndex: 3,
      }}>
        <span>◉ POINTER · X {(mouse.x * 100).toFixed(2)}  Y {(mouse.y * 100).toFixed(2)}</span>
        <span style={{ color: "var(--ink-2)" }}>RENDERED 1,284 NODES · 12,604 EDGES · 60 FPS</span>
        <span>↵  PRESS ENTER TO BOARD</span>
      </div>
    </div>
  );
}

function Bracket({ pos }) {
  const styles = {
    tl: { top: 14, left: 14, borderTop: "1px solid var(--blue)", borderLeft: "1px solid var(--blue)" },
    tr: { top: 14, right: 14, borderTop: "1px solid var(--blue)", borderRight: "1px solid var(--blue)" },
    bl: { bottom: 14, left: 14, borderBottom: "1px solid var(--blue)", borderLeft: "1px solid var(--blue)" },
    br: { bottom: 14, right: 14, borderBottom: "1px solid var(--blue)", borderRight: "1px solid var(--blue)" },
  }[pos];
  return <div style={{ position: "absolute", width: 18, height: 18, opacity: 0.6, zIndex: 5, ...styles }} />;
}

function Live({ label, val, dot }) {
  return (
    <span style={{ display: "inline-flex", alignItems: "center", gap: 6 }}>
      {dot && <span style={{ width: 5, height: 5, borderRadius: "50%", background: "var(--ok)", boxShadow: "0 0 6px var(--ok)" }} />}
      <span style={{ color: "var(--ink-3)" }}>{label}</span>
      <span style={{ color: "var(--ink)" }}>{val}</span>
    </span>
  );
}

function HudPanel({ title, children }) {
  return (
    <div style={{
      background: "rgba(13, 18, 23, 0.55)",
      backdropFilter: "blur(12px)",
      WebkitBackdropFilter: "blur(12px)",
      border: "1px solid rgba(75,166,220,0.22)",
      borderRadius: 10,
      overflow: "hidden",
      boxShadow: "0 10px 40px rgba(0,0,0,0.4)",
    }}>
      <div style={{
        padding: "8px 12px",
        borderBottom: "1px solid rgba(75,166,220,0.18)",
        fontFamily: "var(--mono)", fontSize: 10, letterSpacing: "0.12em",
        color: "var(--blue)",
        background: "rgba(75,166,220,0.05)",
      }}>{title}</div>
      <div>{children}</div>
    </div>
  );
}

window.Onboarding = Onboarding;
