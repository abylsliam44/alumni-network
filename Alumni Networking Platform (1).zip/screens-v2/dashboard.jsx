// Futuristic v2 — Dashboard as command center with radial alumni constellation
function FxDashboard() {
  return (
    <div className="aitu fx" data-screen-label="FX · Dashboard">
      <div className="hud-corners"><i></i></div>
      <FxRail active="home" />
      <div className="stage" style={{ position: "relative" }}>
        <FxTopbar coords="51.13°N · 71.42°E · ASTANA" sess="0xA72F-2026" />

        <div className="body" style={{ flexDirection: "column", overflow: "hidden", padding: "0" }}>
          <div style={{ flex: 1, overflow: "hidden", display: "grid",
                        gridTemplateColumns: "1.05fr 1fr", gridTemplateRows: "1fr",
                        gap: 0 }}>

            {/* Left half — radial constellation + telemetry */}
            <div style={{ position: "relative", borderRight: "1px solid var(--line-soft)", overflow: "hidden" }}>

              {/* corner telemetry */}
              <div style={{ position: "absolute", top: 18, left: 22, zIndex: 2 }}>
                <div className="tele">[ T+06:42 ] · live · <b>147</b> nodes online</div>
                <div className="mega" style={{ marginTop: 8 }}>
                  Good<br/> morning,<br/>
                  <span style={{ color: "var(--blue)" }}>Aizhan</span>.
                </div>
                <div className="tele" style={{ marginTop: 14, lineHeight: 1.7 }}>
                  ↳ <b>3</b> incoming mentorship requests<br/>
                  ↳ <b>2</b> ai matches @ ≥0.90 cosine<br/>
                  ↳ <span className="ok">●</span> profile vector reindexed 4m ago
                </div>
              </div>

              <Constellation />

              {/* Bottom telemetry strip */}
              <div style={{ position: "absolute", bottom: 0, left: 0, right: 0,
                            padding: "14px 22px",
                            borderTop: "1px solid var(--line-soft)",
                            background: "linear-gradient(180deg, transparent, rgba(8,10,12,0.7))",
                            display: "grid", gridTemplateColumns: "repeat(4,1fr)", gap: 16 }}>
                {[
                  { l: "PROFILE INTEGRITY", v: "82.4%", trend: "+04.0", ok: true },
                  { l: "NETWORK DENSITY", v: "1.47k", trend: "+12 pending" },
                  { l: "ACTIVE MENTORSHIPS", v: "02", trend: "next THU 14:00", c: "var(--blue)" },
                  { l: "JOB PIPELINE", v: "05", trend: "1 shortlisted", c: "var(--warm)" },
                ].map((s, i) => (
                  <div key={i}>
                    <div className="tele">{s.l}</div>
                    <div className="mega-mono" style={{ fontSize: 32, color: s.c || "var(--ink)", marginTop: 4 }}>{s.v}</div>
                    <div className="tele" style={{ color: s.ok ? "var(--ok)" : "var(--ink-3)", marginTop: 2 }}>↗ {s.trend}</div>
                  </div>
                ))}
              </div>
            </div>

            {/* Right half — stacked HUD panels */}
            <div style={{ padding: "22px 24px 22px", display: "flex", flexDirection: "column", gap: 14, overflow: "hidden" }}>

              {/* Active transmission */}
              <div className="glass" style={{ padding: "14px 16px" }}>
                <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 10 }}>
                  <div className="tele"><span className="pulse-dot" /> &nbsp;TRANSMISSION · MENTORSHIP_REQUESTS [03]</div>
                  <div className="tele">PRIO · DESC</div>
                </div>
                {[
                  { n: "Daniyar Bekov", t: "b2", role: "Y3 · SE", goal: "Backend career path · 6m", m: 92, prio: "HI" },
                  { n: "Aigerim Sarsen", t: "b6", role: "Y4 · CYBER", goal: "Pen-testing portfolio · 3m", m: 88, prio: "HI" },
                  { n: "Erlan Tursyn", t: "b3", role: "Y2 · DS", goal: "Kaggle to industry · ongoing", m: 74, prio: "MID" },
                ].map((r, i) => (
                  <div key={i} style={{ display: "grid", gridTemplateColumns: "auto 1fr auto auto", gap: 12, alignItems: "center", padding: "8px 0", borderTop: i ? "1px dashed var(--line-soft)" : "none" }}>
                    <Avatar name={r.n} tone={r.t} size="s" />
                    <div style={{ minWidth: 0 }}>
                      <div style={{ fontSize: 12.5, color: "var(--ink)" }}>{r.n} <span className="tele" style={{ marginLeft: 4 }}>· {r.role}</span></div>
                      <div className="mute" style={{ fontSize: 11, marginTop: 1 }}>{r.goal}</div>
                    </div>
                    <div style={{ textAlign: "right" }}>
                      <div className="mono" style={{ fontSize: 11, color: "var(--blue)" }}>{r.m}<span style={{ opacity: 0.5 }}>%</span></div>
                      <div className="tele" style={{ marginTop: 2 }}>{r.prio}</div>
                    </div>
                    <button className="btn sm primary">↗</button>
                  </div>
                ))}
              </div>

              {/* AI matches */}
              <div className="glass" style={{ padding: "14px 16px", flex: 1, minHeight: 0, display: "flex", flexDirection: "column" }}>
                <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 10 }}>
                  <div className="tele"><Icon name="spark" size={11} /> &nbsp;AI · SUGGESTED CONNECTIONS</div>
                  <div className="tele">QDRANT · COSINE</div>
                </div>
                <div style={{ display: "grid", gap: 6, flex: 1, overflow: "hidden" }}>
                  {[
                    { n: "Madina Aldiyar", t: "b4", role: "Senior PM · Beeline", m: 0.94 },
                    { n: "Ruslan Oraz", t: "b8", role: "Founder · Codify", m: 0.91 },
                    { n: "Tomiris Bek", t: "b5", role: "ML Eng · Higgsfield", m: 0.87 },
                  ].map((p, i) => (
                    <div key={i} style={{ display: "grid", gridTemplateColumns: "auto 1fr auto", gap: 10, alignItems: "center", padding: "8px 10px", background: "rgba(75,166,220,0.04)", border: "1px solid var(--line-soft)", borderRadius: 8 }}>
                      <Avatar name={p.n} tone={p.t} size="s" />
                      <div style={{ minWidth: 0 }}>
                        <div style={{ fontSize: 12.5 }}>{p.n}</div>
                        <div className="tele">{p.role}</div>
                      </div>
                      <SimBar v={p.m} />
                    </div>
                  ))}
                </div>
              </div>

              {/* Roadmap quote */}
              <div style={{ padding: "12px 16px", border: "1px dashed var(--blue-line)", borderRadius: 12, background: "rgba(75,166,220,0.04)" }}>
                <div className="tele">// AQYLDY · ROADMAP HINT</div>
                <div className="serif" style={{ fontSize: 18, lineHeight: 1.3, color: "var(--ink)", marginTop: 6 }}>
                  Apply to <span style={{ color: "var(--warm)" }}>2 NIS scholarships</span> before <span style={{ color: "var(--blue)" }}>Jun 1</span> — your profile fits 0.88.
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// Constellation — alumni network visualised as orbital map around "you"
function Constellation() {
  const W = 720, H = 720;
  const cx = W / 2, cy = H / 2 - 30;
  const seed = i => { const x = Math.sin(i * 9301 + 49297) * 233280; return x - Math.floor(x); };
  const rings = [120, 200, 280];
  const dots = [];
  for (let i = 0; i < 140; i++) {
    const ring = i % 3;
    const r = rings[ring] + (seed(i) - 0.5) * 30;
    const a = seed(i + 100) * Math.PI * 2;
    dots.push({ x: cx + Math.cos(a) * r, y: cy + Math.sin(a) * r, r: 1 + seed(i + 200) * 1.6, ring });
  }
  const named = [
    { n: "Madina", r: 110, a: -50, hot: true },
    { n: "Ruslan", r: 140, a: 30 },
    { n: "Tomiris", r: 195, a: -160 },
    { n: "Asem", r: 215, a: 95 },
    { n: "Yerbol", r: 280, a: 220 },
  ];
  return (
    <svg viewBox={`0 0 ${W} ${H}`} width="100%" height="100%" style={{ position: "absolute", inset: 0 }}>
      <defs>
        <radialGradient id="youGlow" cx="50%" cy="50%" r="50%">
          <stop offset="0%" stopColor="#d8a574" stopOpacity="0.7" />
          <stop offset="100%" stopColor="#d8a574" stopOpacity="0" />
        </radialGradient>
      </defs>
      {rings.map((r, i) => (
        <g key={i}>
          <circle cx={cx} cy={cy} r={r} fill="none" stroke="var(--line)" strokeDasharray="1 4" />
          <text x={cx + r + 6} y={cy + 4} fill="var(--ink-3)" fontFamily="var(--mono)" fontSize="9">
            R{i + 1} · {[".90+",".75+",".60+"][i]}
          </text>
        </g>
      ))}
      {/* arc sweep */}
      <path d={`M ${cx - 280} ${cy} A 280 280 0 0 1 ${cx + 280} ${cy}`} fill="none" stroke="var(--blue)" strokeWidth="0.6" strokeDasharray="0.5 6" opacity="0.5" />
      {dots.map((d, i) => (
        <circle key={i} cx={d.x} cy={d.y} r={d.r} fill={d.ring === 0 ? "var(--blue)" : "var(--ink-3)"} opacity={d.ring === 0 ? 0.7 : 0.35} />
      ))}
      {named.map((p, i) => {
        const a = (p.a * Math.PI) / 180;
        const x = cx + Math.cos(a) * p.r, y = cy + Math.sin(a) * p.r;
        return (
          <g key={i}>
            <line x1={cx} y1={cy} x2={x} y2={y} stroke={p.hot ? "var(--blue)" : "var(--blue-line)"} strokeDasharray="1 3" />
            <circle cx={x} cy={y} r={p.hot ? 6 : 4} fill="var(--blue)" />
            {p.hot && <circle cx={x} cy={y} r={11} fill="none" stroke="var(--blue)" opacity={0.5} />}
            <rect x={x + 10} y={y - 9} width={p.n.length * 6 + 14} height={18} rx={9} fill="var(--bg-2)" stroke="var(--line)" />
            <text x={x + 17} y={y + 3} fill="var(--ink-2)" fontFamily="var(--sans)" fontSize="10.5">{p.n}</text>
          </g>
        );
      })}
      {/* center "you" */}
      <circle cx={cx} cy={cy} r={36} fill="url(#youGlow)" />
      <circle cx={cx} cy={cy} r={11} fill="var(--warm)" />
      <circle cx={cx} cy={cy} r={20} fill="none" stroke="var(--warm)" strokeOpacity="0.5" />
      <text x={cx} y={cy + 50} fill="var(--warm)" fontFamily="var(--mono)" fontSize="10" textAnchor="middle">▼ YOU · A.K · Y3</text>
    </svg>
  );
}

function SimBar({ v }) {
  return (
    <div style={{ width: 56, textAlign: "right" }}>
      <div className="mono" style={{ fontSize: 11, color: "var(--blue)" }}>{v.toFixed(2)}</div>
      <div style={{ height: 3, background: "var(--surface-2)", borderRadius: 2, marginTop: 4, overflow: "hidden" }}>
        <div style={{ width: `${v * 100}%`, height: "100%", background: "var(--blue)", boxShadow: "0 0 8px var(--blue)" }} />
      </div>
    </div>
  );
}

function FxRail({ active }) {
  const items = [
    { id: "home", icon: "home" },
    { id: "directory", icon: "users" },
    { id: "mentor", icon: "graph" },
    { id: "jobs", icon: "briefcase" },
    { id: "events", icon: "cal" },
    { id: "msg", icon: "msg" },
    { id: "ai", icon: "spark" },
  ];
  return (
    <div className="fx-rail">
      <div style={{ width: 40, height: 40, borderRadius: 12, background: "var(--ink)", color: "var(--bg)", display: "grid", placeItems: "center", marginBottom: 16, boxShadow: "0 0 24px -6px rgba(75,166,220,0.6)" }}>
        <AituGlyph size={26} color="#0c0e10" accent="#2b7bb8" />
      </div>
      {items.map(it => (
        <div key={it.id} className={`rail-btn${active === it.id ? " active" : ""}`}>
          <Icon name={it.icon} size={20} />
        </div>
      ))}
      <div className="rail-spacer" />
      <div className="rail-btn"><Icon name="bell" size={20} /></div>
      <div className="rail-avatar" style={{ marginTop: 6 }}>AK</div>
    </div>
  );
}

function FxTopbar({ coords, sess }) {
  return (
    <div style={{ height: 44, flex: "0 0 44px", borderBottom: "1px solid var(--line-soft)",
                  display: "flex", alignItems: "center", padding: "0 22px", gap: 16,
                  background: "rgba(8,10,12,0.7)", backdropFilter: "blur(8px)" }}>
      <div className="tele"><span className="pulse-dot" /> &nbsp;LIVE</div>
      <div className="tele">{coords}</div>
      <div className="tele">SESS · {sess}</div>
      <div style={{ flex: 1 }} />
      <div className="tele">⌘K · ANY</div>
      <div className="tele"><span className="pulse-dot warm" /> &nbsp;3 SIGNALS</div>
    </div>
  );
}

window.FxDashboard = FxDashboard;
window.FxRail = FxRail;
window.FxTopbar = FxTopbar;
window.SimBar = SimBar;
