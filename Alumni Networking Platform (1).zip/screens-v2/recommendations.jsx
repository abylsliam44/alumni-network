// Futuristic v2 — Recommendations as full-bleed force-directed network
function FxRecommendations() {
  return (
    <div className="aitu fx" data-screen-label="FX · Recommendations">
      <div className="hud-corners"><i></i></div>
      <FxRail active="directory" />
      <div className="stage" style={{ position: "relative" }}>
        <FxTopbar coords="NETWORK · MESH_VIEW · 1284 NODES" sess="0xRC-001" />
        <div className="body" style={{ flexDirection: "column", overflow: "hidden", position: "relative" }}>

          {/* full-bleed graph */}
          <NetworkMesh />

          {/* Floating header */}
          <div style={{ position: "absolute", top: 24, left: 28, zIndex: 2, maxWidth: 460 }}>
            <div className="tele">[ MESH · LIVE · COSINE ≥ 0.60 ]</div>
            <div className="mega" style={{ fontSize: 56, marginTop: 6 }}>
              <i>12 nodes</i><br/>worth meeting.
            </div>
            <div className="tele" style={{ marginTop: 12, lineHeight: 1.7, color: "var(--ink-2)" }}>
              Computed from your role <b>Y3 SWE</b>, <b>14 skills</b>, mentor flag, career graph signals, proximity to <b>147 connections</b>.
            </div>
          </div>

          {/* Floating detail panel */}
          <div className="glass glow-blue" style={{ position: "absolute", top: 84, right: 28, zIndex: 2, width: 320, padding: 18 }}>
            <div className="tele">SELECTED NODE · 0x4E1</div>
            <div style={{ display: "flex", alignItems: "center", gap: 12, marginTop: 12 }}>
              <Avatar name="Madina Aldiyar" tone="b4" size="l" />
              <div>
                <div className="h3" style={{ fontSize: 16 }}>Madina Aldiyar</div>
                <div className="tele">SR PM · BEELINE KZ</div>
              </div>
            </div>
            <div style={{ marginTop: 12, padding: "10px 12px", background: "rgba(75,166,220,0.06)", border: "1px solid var(--blue-line)", borderRadius: 8 }}>
              <div className="tele">SIMILARITY VECTOR</div>
              <div style={{ display: "flex", alignItems: "baseline", gap: 8, marginTop: 4 }}>
                <span className="mega-mono" style={{ fontSize: 36, color: "var(--blue)" }}>0.94</span>
                <span className="tele">/ 1.00</span>
              </div>
            </div>
            <div className="tele" style={{ marginTop: 12, marginBottom: 6 }}>WHY</div>
            <div style={{ display: "flex", flexDirection: "column", gap: 4 }}>
              {[
                ["Same major + cohort offset", 0.92],
                ["ML interest match", 0.91],
                ["Almaty · 12 mutual events", 0.78],
                ["Active mentor · 4/6 capacity", 0.74],
              ].map(([k, v], i) => (
                <div key={i} style={{ display: "grid", gridTemplateColumns: "1fr auto", gap: 8, alignItems: "center" }}>
                  <span style={{ fontSize: 11.5, color: "var(--ink-2)" }}>{k}</span>
                  <SimBar v={v} />
                </div>
              ))}
            </div>
            <div style={{ display: "flex", gap: 6, marginTop: 14 }}>
              <button className="btn sm" style={{ flex: 1, justifyContent: "center" }}>Skip</button>
              <button className="btn primary sm" style={{ flex: 2, justifyContent: "center" }}>Connect ↗</button>
            </div>
          </div>

          {/* Bottom rank list */}
          <div style={{ position: "absolute", bottom: 0, left: 0, right: 0, zIndex: 2,
                        padding: "14px 28px", borderTop: "1px solid var(--line-soft)",
                        background: "linear-gradient(180deg, transparent, rgba(8,10,12,0.85))",
                        backdropFilter: "blur(6px)" }}>
            <div className="tele" style={{ marginBottom: 8 }}>↳ TOP CANDIDATES · SCROLL TO INSPECT</div>
            <div style={{ display: "flex", gap: 10, overflowX: "auto" }}>
              {[
                { n: "Madina Aldiyar", t: "b4", role: "Sr PM · Beeline", m: 0.94, sel: true },
                { n: "Ruslan Oraz", t: "b8", role: "Founder · Codify", m: 0.91 },
                { n: "Tomiris Bek", t: "b5", role: "ML Eng · Higgsfield", m: 0.87 },
                { n: "Asem Nazarbek", t: "b6", role: "EM · Kolesa", m: 0.84 },
                { n: "Yerbol S.", t: "b1", role: "Staff SWE · Stripe", m: 0.81 },
                { n: "Aisha Nurlan", t: "b6", role: "iOS · Halyk", m: 0.79 },
                { n: "Daulet Kim", t: "b7", role: "Data Eng · Kaspi", m: 0.76 },
                { n: "Dinara A.", t: "b4", role: "Tech Lead · Halyk", m: 0.69 },
              ].map((p, i) => (
                <div key={i} className={p.sel ? "glow-blue" : ""} style={{
                  flex: "0 0 220px",
                  padding: "10px 12px",
                  borderRadius: 10,
                  background: p.sel ? "var(--blue-soft)" : "var(--surface)",
                  border: "1px solid " + (p.sel ? "var(--blue-line)" : "var(--line)"),
                  display: "grid", gridTemplateColumns: "auto 1fr auto", gap: 10, alignItems: "center",
                }}>
                  <Avatar name={p.n} tone={p.t} size="s" />
                  <div style={{ minWidth: 0 }}>
                    <div style={{ fontSize: 12, color: "var(--ink)" }}>{p.n}</div>
                    <div className="tele">{p.role}</div>
                  </div>
                  <div className="mono" style={{ fontSize: 11, color: "var(--blue)" }}>{p.m.toFixed(2)}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// Force-directed-looking network mesh (statically positioned for determinism)
function NetworkMesh() {
  const W = 1380, H = 880;
  const seed = i => { const x = Math.sin(i * 9301 + 49297) * 233280; return x - Math.floor(x); };
  const nodes = [];
  const cx = W / 2, cy = H / 2;
  // YOU node
  nodes.push({ x: cx - 60, y: cy - 30, r: 12, you: true, label: "YOU" });
  // top tier — named close
  const named = [
    { n: "Madina", x: cx + 130, y: cy - 90, r: 9, sel: true, hot: true },
    { n: "Ruslan", x: cx - 180, y: cy + 80, r: 8, hot: true },
    { n: "Tomiris", x: cx + 90, y: cy + 130, r: 8, hot: true },
    { n: "Asem", x: cx - 280, y: cy - 60, r: 7 },
    { n: "Yerbol", x: cx + 280, y: cy + 40, r: 7 },
    { n: "Aisha", x: cx + 200, y: cy - 200, r: 6 },
    { n: "Daulet", x: cx - 90, y: cy + 220, r: 6 },
  ];
  named.forEach(n => nodes.push(n));
  // anonymous cloud
  for (let i = 0; i < 110; i++) {
    const a = seed(i) * Math.PI * 2;
    const r = 200 + seed(i + 100) * 280;
    nodes.push({
      x: cx + Math.cos(a) * r + (seed(i + 200) - 0.5) * 60,
      y: cy + Math.sin(a) * r * 0.6 + (seed(i + 300) - 0.5) * 60,
      r: 1.5 + seed(i + 400) * 2.2,
      faint: true,
    });
  }
  // edges
  const edges = [];
  // you → named
  named.forEach((n, i) => edges.push({ a: 0, b: i + 1, hot: n.hot }));
  // among named
  edges.push({ a: 1, b: 3 }); edges.push({ a: 1, b: 6 });
  edges.push({ a: 2, b: 4 }); edges.push({ a: 3, b: 5 });
  edges.push({ a: 5, b: 7 }); edges.push({ a: 4, b: 7 });
  // some anon cluster lines
  for (let i = 0; i < 80; i++) {
    const a = 8 + Math.floor(seed(i + 500) * 110);
    const b = 8 + Math.floor(seed(i + 600) * 110);
    if (a !== b) edges.push({ a, b, faint: true });
  }
  return (
    <svg viewBox={`0 0 ${W} ${H}`} width="100%" height="100%" style={{ position: "absolute", inset: 0 }}>
      <defs>
        <radialGradient id="nodeYouGlow" cx="50%" cy="50%" r="50%">
          <stop offset="0%" stopColor="#d8a574" stopOpacity="0.6" />
          <stop offset="100%" stopColor="#d8a574" stopOpacity="0" />
        </radialGradient>
      </defs>
      {edges.map((e, i) => {
        const a = nodes[e.a], b = nodes[e.b];
        if (!a || !b) return null;
        return (
          <line key={i} x1={a.x} y1={a.y} x2={b.x} y2={b.y}
                stroke={e.hot ? "var(--blue)" : (e.faint ? "var(--line)" : "var(--line)")}
                strokeWidth={e.hot ? 1.2 : 0.6}
                strokeOpacity={e.hot ? 0.7 : (e.faint ? 0.25 : 0.45)} />
        );
      })}
      {nodes.map((n, i) => {
        if (n.you) {
          return (
            <g key={i}>
              <circle cx={n.x} cy={n.y} r={48} fill="url(#nodeYouGlow)" />
              <circle cx={n.x} cy={n.y} r={n.r} fill="var(--warm)" />
              <circle cx={n.x} cy={n.y} r={n.r + 6} fill="none" stroke="var(--warm)" strokeOpacity="0.5" />
              <text x={n.x} y={n.y + n.r + 18} fill="var(--warm)" fontFamily="var(--mono)" fontSize="10" textAnchor="middle">▼ YOU · A.K</text>
            </g>
          );
        }
        if (n.n) {
          return (
            <g key={i}>
              {n.sel && <circle cx={n.x} cy={n.y} r={n.r + 8} fill="none" stroke="var(--blue)" strokeWidth="1" />}
              <circle cx={n.x} cy={n.y} r={n.r} fill={n.hot ? "var(--blue)" : "var(--ink-2)"} />
              <text x={n.x + n.r + 6} y={n.y + 3} fill="var(--ink)" fontFamily="var(--sans)" fontSize="11">{n.n}</text>
            </g>
          );
        }
        return <circle key={i} cx={n.x} cy={n.y} r={n.r} fill="var(--ink-3)" opacity={0.35} />;
      })}
    </svg>
  );
}

window.FxRecommendations = FxRecommendations;
