// App — wires every screen into a DesignCanvas of artboards
const {
  Onboarding,
  Dashboard, Profile, Directory, Mentorship, AiChat, Recommendations, ResumeImport, Jobs,
  FxDashboard, FxProfile, FxAiChat, FxRecommendations,
} = window;

const SCREEN_W = 1380;
const SCREEN_H = 880;

function App() {
  return (
    <DesignCanvas>
      <DCSection
        id="onb"
        title="Onboarding — cursor-tracking constellation"
        subtitle="Interactive landing. Move your cursor across the canvas — nodes pull toward it, scanning rings track, gradient field follows the pointer."
      >
        <DCArtboard id="onboarding" label="00 · Onboarding · Enter the network" width={SCREEN_W} height={SCREEN_H}>
          <Onboarding />
        </DCArtboard>
      </DCSection>

      <DCSection
        id="fx"
        title="Futuristic v2 — HUD / orbital / mesh"
        subtitle="Pushed further: ambient grids, glass panels, telemetry typography, network as the page itself"
      >
        <DCArtboard id="fx-dashboard" label="01 · Command center" width={SCREEN_W} height={SCREEN_H}>
          <FxDashboard />
        </DCArtboard>
        <DCArtboard id="fx-profile" label="02 · Profile · Orbital trajectory" width={SCREEN_W} height={SCREEN_H}>
          <FxProfile />
        </DCArtboard>
        <DCArtboard id="fx-recs" label="03 · Recommendations · Mesh" width={SCREEN_W} height={SCREEN_H}>
          <FxRecommendations />
        </DCArtboard>
        <DCArtboard id="fx-ai" label="04 · AqyldyAI · Oracle" width={SCREEN_W} height={SCREEN_H}>
          <FxAiChat />
        </DCArtboard>
      </DCSection>

      <DCSection
        id="core"
        title="v1 — Editorial dark (original direction)"
        subtitle="Hi-fi screen overview · dark, editorial, AITU palette as accent"
      >
        <DCArtboard id="dashboard" label="01 · Dashboard" width={SCREEN_W} height={SCREEN_H}>
          <Dashboard />
        </DCArtboard>
        <DCArtboard id="profile" label="02 · Profile · Career trajectory" width={SCREEN_W} height={SCREEN_H}>
          <Profile />
        </DCArtboard>
        <DCArtboard id="directory" label="03 · Directory + Connections" width={SCREEN_W} height={SCREEN_H}>
          <Directory />
        </DCArtboard>
        <DCArtboard id="mentorship" label="04 · Mentorship · Active + matching" width={SCREEN_W} height={SCREEN_H}>
          <Mentorship />
        </DCArtboard>
      </DCSection>

      <DCSection
        id="intel"
        title="v1 — Intelligence layer"
        subtitle="AI matching, RAG-powered assistant, resume understanding"
      >
        <DCArtboard id="recs" label="05 · Recommendations · AI people match" width={SCREEN_W} height={SCREEN_H}>
          <Recommendations />
        </DCArtboard>
        <DCArtboard id="ai" label="06 · AqyldyAI · Assistant" width={SCREEN_W} height={SCREEN_H}>
          <AiChat />
        </DCArtboard>
        <DCArtboard id="resume" label="07 · Resume Import · Review draft" width={SCREEN_W} height={SCREEN_H}>
          <ResumeImport />
        </DCArtboard>
        <DCArtboard id="jobs" label="08 · Jobs · Board + detail" width={SCREEN_W} height={SCREEN_H}>
          <Jobs />
        </DCArtboard>
      </DCSection>
    </DesignCanvas>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
