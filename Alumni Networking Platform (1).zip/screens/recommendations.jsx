// Recommendations — AI-driven people recommendations with explainability
function Recommendations() {
  return (
    <div className="aitu" data-screen-label="Recommendations">
      <Rail active="directory" />
      <div className="stage">
        <Topbar crumb={["Network", "Recommendations"]} />
        <div className="body" style={{ flexDirection: "column", overflow: "hidden" }}>
          <div style={{ flex: 1, overflowY: "auto", padding: "28px 36px 36px" }}>

            <div style={{ display: "grid", gridTemplateColumns: "1.2fr 1fr", alignItems: "end", gap: 24, marginBottom: 24 }}>
              <div>
                <div className="eyebrow" style={{ marginBottom: 10 }}>RECOMMENDATIONS · QDRANT EMBEDDINGS</div>
                <div className="h1">
                  <i>12 people</i> the model thinks<br />
                  you should <span style={{ color: "var(--blue)" }}>actually meet</span>.
                </div>
              </div>
              <div className="panel" style={{ padding: "12px 14px", background: "var(--bg-2)" }}>
                <div className="mono" style={{ fontSize: 10, color: "var(--ink-3)", letterSpacing: "0.06em", marginBottom: 6 }}>WHY THESE RESULTS</div>
                <div style={{ fontSize: 12, color: "var(--ink-2)", lineHeight: 1.5 }}>
                  Computed from your role <b style={{ color: "var(--ink)" }}>(Y3 SWE)</b>, <b style={{ color: "var(--ink)" }}>14 skills</b>, mentor status preference, career graph signals, and proximity to <b style={{ color: "var(--ink)" }}>147 connections</b>. Reindexed 4m ago.
                </div>
              </div>
            </div>

            {/* Featured top-3 row */}
            <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 16, marginBottom: 28 }}>
              {[
                { n: "Madina Aldiyar", t: "b4", role: "Senior PM · Beeline KZ", m: 94, why: ["Same major + cohort offset", "ML interest match · 0.91", "Almaty · 12 mutual events"], rank: 1 },
                { n: "Ruslan Oraz", t: "b8", role: "Founder · Codify", m: 91, why: ["Hires ML interns · open", "3 mutual connections", "Active mentor · capacity 2/4"], rank: 2 },
                { n: "Tomiris Bek", t: "b5", role: "ML Eng · Higgsfield", m: 87, why: ["Same Kaggle competition", "PyTorch + MLOps overlap", "Recent post on RAG"], rank: 3 },
              ].map((p, i) => (
                <div key={i} className="panel" style={{ padding: 18, position: "relative", background: "linear-gradient(180deg, rgba(75,166,220,0.04), transparent), var(--surface)", borderColor: "var(--blue-line)" }}>
                  <div style={{ position: "absolute", top: 14, right: 14, fontFamily: "var(--serif)", fontStyle: "italic", fontSize: 38, color: "var(--ink-4)", lineHeight: 1 }}>
                    {String(p.rank).padStart(2, "0")}
                  </div>
                  <Avatar name={p.n} tone={p.t} size="l" />
                  <div className="h3" style={{ marginTop: 12, fontSize: 16 }}>{p.n}</div>
                  <div className="mute" style={{ fontSize: 12, marginBottom: 14 }}>{p.role}</div>
                  <div style={{ display: "flex", flexDirection: "column", gap: 6, paddingTop: 14, borderTop: "1px dashed var(--line)" }}>
                    {p.why.map((w, j) => (
                      <div key={j} className="mono" style={{ fontSize: 10.5, color: "var(--blue)" }}>+ {w}</div>
                    ))}
                  </div>
                  <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginTop: 14 }}>
                    <span className="mono" style={{ fontSize: 12, color: "var(--blue)", fontWeight: 600 }}>{p.m}% match</span>
                    <div style={{ display: "flex", gap: 6 }}>
                      <button className="btn sm">Skip</button>
                      <button className="btn sm primary">Connect</button>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Embedding map (signature visual) */}
            <div className="eyebrow" style={{ marginBottom: 12 }}>02 · SIMILARITY MAP · 1,284 ALUMNI</div>
            <div className="panel" style={{ padding: 16, marginBottom: 28, background: "var(--bg-2)" }}>
              <SimilarityMap />
            </div>

            {/* Lower list */}
            <div className="eyebrow" style={{ marginBottom: 12 }}>03 · MORE TO EXPLORE</div>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 10 }}>
              {[
                { n: "Aisha Nurlan", t: "b6", role: "iOS Eng · Halyk", m: 79 },
                { n: "Daulet Kim", t: "b7", role: "Data Eng · Kaspi", m: 76 },
                { n: "Yerbol Sergaziyev", t: "b1", role: "Staff SWE · Stripe", m: 74 },
                { n: "Aigerim Sarsen", t: "b6", role: "Y4 · CyberSec", m: 71 },
                { n: "Dinara Auelbek", t: "b4", role: "Tech Lead · Halyk", m: 69 },
                { n: "Marat Onlasyn", t: "b3", role: "Founder · stealth", m: 66 },
              ].map((p, i) => (
                <div key={i} className="panel" style={{ padding: "10px 12px", display: "grid", gridTemplateColumns: "auto 1fr auto", gap: 10, alignItems: "center" }}>
                  <Avatar name={p.n} tone={p.t} size="s" />
                  <div style={{ minWidth: 0 }}>
                    <div style={{ fontSize: 12.5 }}>{p.n}</div>
                    <div className="mute mono" style={{ fontSize: 10 }}>{p.role}</div>
                  </div>
                  <span className="mono" style={{ fontSize: 10.5, color: "var(--blue)" }}>{p.m}%</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// Concentric similarity map: you at center, alumni clouds at varying distances/angles
function SimilarityMap() {
  const W = 1180, H = 320;
  const cx = W / 2, cy = H / 2;
  const rings = [
    { r: 60, label: "0.9+ · close", color: "var(--blue)" },
    { r: 110, label: "0.75+", color: "var(--blue)" },
    { r: 160, label: "0.6+", color: "var(--ink-3)" },
    { r: 220, label: "0.4+", color: "var(--ink-3)" },
  ];
  // deterministic seeded points
  const seed = (i) => {
    const x = Math.sin(i * 9301 + 49297) * 233280;
    return x - Math.floor(x);
  };
  const dots = [];
  const named = [
    { n: "Madina", r: 55, a: 30, t: 0 },
    { n: "Ruslan", r: 70, a: 160, t: 1 },
    { n: "Tomiris", r: 95, a: 290, t: 2 },
    { n: "Asem", r: 130, a: 80, t: 3 },
    { n: "Yerbol", r: 175, a: 220, t: 4 },
  ];
  for (let i = 0; i < 220; i++) {
    const ring = Math.floor(seed(i) * 4);
    const r = (rings[ring]?.r || 220) + (seed(i + 100) - 0.5) * 30;
    const a = seed(i + 200) * Math.PI * 2;
    const x = cx + Math.cos(a) * r;
    const y = cy + Math.sin(a) * r * 0.65;
    dots.push({ x, y, r: 1.5 + seed(i + 300) * 1.5, ring });
  }
  return (
    <svg viewBox={`0 0 ${W} ${H}`} width="100%" height={H}>
      {/* rings */}
      {rings.map((ring, i) => (
        <g key={i}>
          <ellipse cx={cx} cy={cy} rx={ring.r} ry={ring.r * 0.65} fill="none" stroke="var(--line)" strokeDasharray="2 4" />
          <text x={cx + ring.r + 8} y={cy + 3} fill="var(--ink-3)" fontFamily="var(--mono)" fontSize="9">{ring.label}</text>
        </g>
      ))}
      {/* anonymous dots */}
      {dots.map((d, i) => (
        <circle key={i} cx={d.x} cy={d.y} r={d.r} fill={d.ring < 2 ? "var(--blue)" : "var(--ink-3)"} opacity={d.ring < 2 ? 0.65 : 0.35} />
      ))}
      {/* named highlights */}
      {named.map((p, i) => {
        const a = (p.a * Math.PI) / 180;
        const x = cx + Math.cos(a) * p.r;
        const y = cy + Math.sin(a) * p.r * 0.65;
        return (
          <g key={i}>
            <line x1={cx} y1={cy} x2={x} y2={y} stroke="var(--blue-line)" strokeDasharray="1 3" />
            <circle cx={x} cy={y} r={5} fill="var(--blue)" />
            <circle cx={x} cy={y} r={9} fill="none" stroke="var(--blue)" opacity="0.4" />
            <text x={x + 12} y={y + 3} fill="var(--ink)" fontFamily="var(--sans)" fontSize="11">{p.n}</text>
          </g>
        );
      })}
      {/* you */}
      <circle cx={cx} cy={cy} r={9} fill="var(--warm)" />
      <circle cx={cx} cy={cy} r={16} fill="none" stroke="var(--warm)" strokeOpacity="0.4" />
      <text x={cx} y={cy - 22} fill="var(--warm)" fontFamily="var(--mono)" fontSize="10" textAnchor="middle">YOU · AIZHAN</text>
    </svg>
  );
}

window.Recommendations = Recommendations;
