// Mentorship — overview of mentor matching + active session view
function Mentorship() {
  return (
    <div className="aitu" data-screen-label="Mentorship">
      <Rail active="mentor" />
      <div className="stage">
        <Topbar crumb={["Mentorship", "Active · with Madiyar Toleu"]} />
        <div className="body" style={{ flexDirection: "column", overflow: "hidden" }}>
          <div style={{ flex: 1, overflowY: "auto", padding: "24px 32px 32px" }}>

            <div style={{ display: "flex", alignItems: "baseline", justifyContent: "space-between", marginBottom: 20 }}>
              <div>
                <div className="eyebrow" style={{ marginBottom: 8 }}>MENTORSHIP · 1 ACTIVE · 2 INCOMING</div>
                <div className="h1" style={{ fontSize: 32 }}>Week <i>06</i> with <span style={{ color: "var(--blue)" }}>Madiyar</span> — backend interview prep.</div>
              </div>
              <div style={{ display: "flex", gap: 8 }}>
                <button className="btn"><Icon name="msg" size={14} /> Message mentor</button>
                <button className="btn primary"><Icon name="cal" size={14} /> Schedule session</button>
              </div>
            </div>

            {/* Two-column: plan & sessions / matching */}
            <div style={{ display: "grid", gridTemplateColumns: "1.6fr 1fr", gap: 20 }}>

              {/* Active mentorship plan */}
              <div className="panel" style={{ overflow: "hidden" }}>
                <div style={{ padding: "16px 18px", borderBottom: "1px solid var(--line-soft)", display: "grid", gridTemplateColumns: "auto 1fr auto", gap: 14, alignItems: "center" }}>
                  <Avatar name="Madiyar Toleu" tone="b3" size="l" />
                  <div>
                    <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 2 }}>
                      <div className="h3">Madiyar Toleu</div>
                      <Pill tone="blue" dot>active · week 6/12</Pill>
                    </div>
                    <div className="mute mono" style={{ fontSize: 10.5 }}>SENIOR SWE · KASPI · CLASS '18</div>
                  </div>
                  <div style={{ display: "flex", gap: 4 }}>
                    <button className="iconbtn"><Icon name="more" /></button>
                  </div>
                </div>

                {/* Plan progress */}
                <div style={{ padding: "20px 18px 6px" }}>
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline", marginBottom: 12 }}>
                    <div className="eyebrow">PLAN · GOAL: LAND BACKEND INTERN</div>
                    <span className="mono" style={{ fontSize: 10, color: "var(--blue)" }}>50% COMPLETE</span>
                  </div>
                  <Milestones />
                </div>

                {/* Sessions */}
                <div style={{ padding: "20px 18px 18px" }}>
                  <div className="eyebrow" style={{ marginBottom: 12 }}>SESSIONS · 3 PAST · 1 UPCOMING</div>
                  <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
                    {[
                      { d: "MAY 12", t: "14:00", title: "Mock interview — system design", st: "upcoming", room: "platform-mentorship-session-7c2a" },
                      { d: "MAY 05", t: "14:00", title: "Resume review + STAR stories", st: "done", note: "3 actions captured" },
                      { d: "APR 28", t: "14:00", title: "Career goals + 12-week plan", st: "done", note: "Plan signed off" },
                      { d: "APR 21", t: "14:00", title: "Intro · expectations", st: "done" },
                    ].map((s, i) => (
                      <div key={i} style={{ display: "grid", gridTemplateColumns: "70px 1fr auto auto", gap: 14, alignItems: "center", padding: "10px 12px", borderRadius: 8, background: s.st === "upcoming" ? "var(--blue-soft)" : "var(--bg-2)", border: "1px solid " + (s.st === "upcoming" ? "var(--blue-line)" : "var(--line-soft)") }}>
                        <div className="mono" style={{ fontSize: 10.5, color: s.st === "upcoming" ? "var(--blue)" : "var(--ink-3)" }}>
                          <div style={{ fontWeight: 600 }}>{s.d}</div>
                          <div>{s.t}</div>
                        </div>
                        <div>
                          <div className="h3" style={{ fontSize: 13 }}>{s.title}</div>
                          {s.note && <div className="mute" style={{ fontSize: 11, marginTop: 2 }}>{s.note}</div>}
                          {s.room && <div className="mono" style={{ fontSize: 10, color: "var(--blue)", marginTop: 2 }}>{s.room}</div>}
                        </div>
                        {s.st === "done" && <Pill tone="ok" dot>done</Pill>}
                        {s.st === "upcoming" && (
                          <button className="btn sm blue"><Icon name="msg" size={12} /> Join call</button>
                        )}
                        {s.st === "done" && <Icon name="external" size={14} color="var(--ink-3)" />}
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Right: AI matching for new mentor */}
              <div>
                <div className="panel" style={{ background: "linear-gradient(180deg, rgba(75,166,220,0.05), transparent 50%), var(--surface)", borderColor: "var(--blue-line)" }}>
                  <div className="panel-head" style={{ borderBottomColor: "var(--blue-line)" }}>
                    <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                      <Icon name="spark" size={14} color="var(--blue)" />
                      <h3>Suggested next mentors</h3>
                    </div>
                    <span className="mono" style={{ fontSize: 9.5, color: "var(--ink-3)", letterSpacing: "0.06em" }}>QDRANT · COSINE</span>
                  </div>
                  <div style={{ padding: "8px 0" }}>
                    {[
                      { n: "Asem Nazarbek", t: "b6", role: "Engineering Mgr · Kolesa", m: 96, sig: ["+ Backend → Eng mgmt", "+ Mentored 14"] },
                      { n: "Yerbol Sergaziyev", t: "b1", role: "Staff SWE · Stripe", m: 89, sig: ["+ Distributed sys", "+ FAANG path"] },
                      { n: "Dinara Auelbek", t: "b4", role: "Tech Lead · Halyk", m: 84, sig: ["+ Same major", "+ 5 mutuals"] },
                    ].map((p, i) => (
                      <div key={i} style={{ padding: "10px 16px", borderTop: i ? "1px solid var(--line-soft)" : "none", display: "grid", gridTemplateColumns: "auto 1fr auto", gap: 10, alignItems: "center" }}>
                        <Avatar name={p.n} tone={p.t} />
                        <div style={{ minWidth: 0 }}>
                          <div className="h3" style={{ fontSize: 12.5 }}>{p.n}</div>
                          <div className="mute mono" style={{ fontSize: 10 }}>{p.role}</div>
                          <div style={{ fontSize: 10.5, color: "var(--blue)", marginTop: 4, lineHeight: 1.4 }}>{p.sig.join(" ")}</div>
                        </div>
                        <div style={{ textAlign: "right" }}>
                          <div className="mono" style={{ fontSize: 11, color: "var(--blue)", fontWeight: 600 }}>{p.m}%</div>
                          <button className="btn sm" style={{ marginTop: 4 }}>Request</button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Incoming requests stack */}
                <div className="eyebrow" style={{ margin: "24px 0 10px" }}>02 · YOU AS MENTOR · 2 INCOMING</div>
                <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
                  {[
                    { n: "Daniyar Bekov", t: "b2", goal: "Backend career · 6m", time: "2h" },
                    { n: "Aigerim Sarsen", t: "b6", goal: "Pen-testing portfolio · 3m", time: "6h" },
                  ].map((r, i) => (
                    <div key={i} className="panel" style={{ padding: 12, display: "grid", gridTemplateColumns: "auto 1fr auto", gap: 10, alignItems: "center" }}>
                      <Avatar name={r.n} tone={r.t} />
                      <div style={{ minWidth: 0 }}>
                        <div className="h3" style={{ fontSize: 12.5 }}>{r.n}</div>
                        <div className="mute" style={{ fontSize: 11 }}>{r.goal}</div>
                      </div>
                      <div style={{ display: "flex", gap: 4 }}>
                        <button className="btn sm ghost">Decline</button>
                        <button className="btn sm primary">Accept</button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function Milestones() {
  const list = [
    { t: "Define target companies & roles", done: true },
    { t: "Resume + GitHub polished", done: true },
    { t: "STAR stories for behavioral", done: true },
    { t: "System design fundamentals", done: false, current: true },
    { t: "Mock interview · technical", done: false },
    { t: "Negotiation playbook", done: false },
  ];
  return (
    <div style={{ display: "flex", alignItems: "stretch", gap: 0 }}>
      {list.map((m, i) => (
        <div key={i} style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "stretch", position: "relative" }}>
          <div style={{ display: "flex", alignItems: "center" }}>
            <div style={{
              width: 22, height: 22, borderRadius: "50%",
              background: m.done ? "var(--ok)" : (m.current ? "var(--blue)" : "var(--bg-2)"),
              border: "1.5px solid " + (m.done ? "var(--ok)" : m.current ? "var(--blue)" : "var(--ink-4)"),
              display: "grid", placeItems: "center",
              color: m.done ? "var(--bg)" : "var(--ink)", flex: "0 0 auto",
            }}>
              {m.done ? <Icon name="check" size={11} /> : (m.current ? <span className="mono" style={{ fontSize: 10, color: "var(--bg)", fontWeight: 700 }}>{i + 1}</span> : <span className="mono" style={{ fontSize: 10, color: "var(--ink-3)" }}>{i + 1}</span>)}
            </div>
            {i < list.length - 1 && (
              <div style={{ flex: 1, height: 2, background: m.done ? "var(--ok)" : "var(--line)" }} />
            )}
          </div>
          <div style={{ paddingTop: 10, paddingRight: 10, fontSize: 11.5, color: m.current ? "var(--ink)" : (m.done ? "var(--ink-2)" : "var(--ink-3)"), lineHeight: 1.3 }}>
            {m.t}
            {m.current && <div className="mono" style={{ fontSize: 9.5, color: "var(--blue)", marginTop: 4 }}>IN PROGRESS</div>}
          </div>
        </div>
      ))}
    </div>
  );
}
window.Mentorship = Mentorship;
