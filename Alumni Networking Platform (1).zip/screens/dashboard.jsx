// Dashboard — agg view, asymmetric, hero stat strip + activity columns
function Dashboard() {
  return (
    <div className="aitu" data-screen-label="Dashboard">
      <Rail active="home" />
      <div className="stage">
        <Topbar crumb={["Aizhan Kuanysh", "Dashboard"]} />
        <div className="body" style={{ flexDirection: "column", overflow: "hidden" }}>
          <div style={{ flex: 1, overflowY: "auto", padding: "28px 36px 36px" }}>

            {/* Hero strip */}
            <div style={{ display: "grid", gridTemplateColumns: "1fr auto", alignItems: "end", gap: 24, marginBottom: 28 }}>
              <div>
                <div className="eyebrow" style={{ marginBottom: 10 }}>06 · MAY · 2026 · TUESDAY</div>
                <div className="h1">
                  Good morning, Aizhan.<br />
                  You have <i>3 incoming</i> mentorship requests<br />
                  and <span style={{ color: "var(--blue)" }}>2 new matches</span> this week.
                </div>
              </div>
              <div style={{ display: "flex", gap: 8 }}>
                <button className="btn"><Icon name="plus" /> Compose</button>
                <button className="btn primary">Resume Import →</button>
              </div>
            </div>

            {/* Stats */}
            <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 0, border: "1px solid var(--line-soft)", borderRadius: 12, marginBottom: 28, background: "var(--surface)" }}>
              {[
                { k: "Profile completeness", v: "82%", sub: "+4 this month", tone: "var(--ok)" },
                { k: "Connections", v: "147", sub: "12 new pending" },
                { k: "Active mentorships", v: "2", sub: "next session Thu 14:00", tone: "var(--blue)" },
                { k: "Job applications", v: "5", sub: "2 viewed · 1 shortlisted", tone: "var(--warm)" },
              ].map((s, i) => (
                <div key={i} style={{ padding: "18px 22px", borderRight: i < 3 ? "1px solid var(--line-soft)" : "none" }}>
                  <div className="eyebrow" style={{ marginBottom: 10 }}>{s.k}</div>
                  <div style={{ fontSize: 30, fontWeight: 500, letterSpacing: "-0.02em", color: s.tone || "var(--ink)" }}>{s.v}</div>
                  <div className="mono" style={{ fontSize: 10.5, color: "var(--ink-3)", marginTop: 4 }}>{s.sub}</div>
                </div>
              ))}
            </div>

            {/* Three columns */}
            <div style={{ display: "grid", gridTemplateColumns: "1.3fr 1fr 1fr", gap: 20 }}>

              {/* Mentorship requests */}
              <div className="panel">
                <div className="panel-head">
                  <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                    <NumCap n={1} />
                    <h3>Incoming mentorship requests</h3>
                  </div>
                  <Pill tone="blue" dot>3 new</Pill>
                </div>
                <div className="panel-body" style={{ padding: 0 }}>
                  {[
                    { name: "Daniyar Bekov", t: "b2", role: "Y3 · Software Eng", goal: "Backend career path · 6 months", time: "2h ago", match: 92 },
                    { name: "Aigerim Sarsen", t: "b6", role: "Y4 · Cybersecurity", goal: "Pen-testing portfolio · 3 months", time: "6h ago", match: 88 },
                    { name: "Erlan Tursyn", t: "b3", role: "Y2 · Data Science", goal: "Kaggle to industry · ongoing", time: "1d ago", match: 74 },
                  ].map((r, i) => (
                    <div key={i} style={{ padding: "14px 16px", borderTop: "1px solid var(--line-soft)", display: "grid", gridTemplateColumns: "auto 1fr auto", gap: 12, alignItems: "center" }}>
                      <Avatar name={r.name} tone={r.t} />
                      <div style={{ minWidth: 0 }}>
                        <div className="h3" style={{ marginBottom: 2 }}>{r.name}
                          <span className="mono" style={{ marginLeft: 8, fontSize: 10, color: "var(--ink-3)" }}>{r.role}</span>
                        </div>
                        <div className="mute" style={{ fontSize: 12 }}>{r.goal}</div>
                      </div>
                      <div style={{ display: "flex", flexDirection: "column", alignItems: "flex-end", gap: 6 }}>
                        <div className="mono" style={{ fontSize: 10, color: "var(--blue)" }}>{r.match}% match</div>
                        <div style={{ display: "flex", gap: 4 }}>
                          <button className="btn sm ghost">Decline</button>
                          <button className="btn sm primary">Accept</button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Upcoming */}
              <div className="panel">
                <div className="panel-head">
                  <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                    <NumCap n={2} />
                    <h3>Upcoming</h3>
                  </div>
                  <span className="mono mute" style={{ fontSize: 10 }}>this week</span>
                </div>
                <div className="panel-body" style={{ padding: 0 }}>
                  {[
                    { d: "THU", n: "08", t: "14:00", title: "Session w/ Madiyar Toleu", sub: "Career strategy · 30m", tone: "blue" },
                    { d: "FRI", n: "09", t: "18:30", title: "AITU × Kaspi · Tech Talk", sub: "Online · 240 attending", tone: null },
                    { d: "MON", n: "12", t: "11:00", title: "Resume review w/ Asem", sub: "Mentor session", tone: null },
                    { d: "WED", n: "14", t: "—", title: "Application deadline", sub: "JusanBank Backend Intern", tone: "warm" },
                  ].map((e, i) => (
                    <div key={i} style={{ padding: "12px 16px", borderTop: "1px solid var(--line-soft)", display: "grid", gridTemplateColumns: "44px 1fr auto", gap: 12, alignItems: "center" }}>
                      <div style={{ textAlign: "center", padding: "4px 0", border: "1px solid var(--line)", borderRadius: 6, background: e.tone ? `var(--${e.tone}-soft)` : "var(--bg-2)" }}>
                        <div className="mono" style={{ fontSize: 9, color: "var(--ink-3)", letterSpacing: "0.08em" }}>{e.d}</div>
                        <div className="mono" style={{ fontSize: 14, color: e.tone ? `var(--${e.tone})` : "var(--ink)", fontWeight: 600 }}>{e.n}</div>
                      </div>
                      <div style={{ minWidth: 0 }}>
                        <div className="h3" style={{ fontSize: 13, marginBottom: 2 }}>{e.title}</div>
                        <div className="mute" style={{ fontSize: 11 }}>{e.sub}</div>
                      </div>
                      <span className="mono mute" style={{ fontSize: 10 }}>{e.t}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* AI matches */}
              <div className="panel" style={{ borderColor: "var(--blue-line)", background: "linear-gradient(180deg, rgba(75,166,220,0.04), transparent 60%) , var(--surface)" }}>
                <div className="panel-head" style={{ borderBottomColor: "var(--blue-line)" }}>
                  <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                    <NumCap n={3} />
                    <h3>AI suggests you connect with</h3>
                  </div>
                  <Icon name="spark" size={14} color="var(--blue)" />
                </div>
                <div className="panel-body" style={{ padding: 0 }}>
                  {[
                    { n: "Madina Aldiyar", t: "b4", role: "Senior PM · Beeline KZ", why: "+ Same major · Almaty · ML interest", m: 94 },
                    { n: "Ruslan Oraz", t: "b8", role: "Founder · Codify", why: "+ Wants ML interns · 3 mutuals", m: 91 },
                    { n: "Tomiris Bek", t: "b5", role: "ML Eng · Higgsfield", why: "+ Same Kaggle competition", m: 87 },
                  ].map((p, i) => (
                    <div key={i} style={{ padding: "12px 16px", borderTop: "1px solid var(--line-soft)", display: "grid", gridTemplateColumns: "auto 1fr auto", gap: 10, alignItems: "center" }}>
                      <Avatar name={p.n} tone={p.t} size="s" />
                      <div style={{ minWidth: 0 }}>
                        <div className="h3" style={{ fontSize: 12.5, marginBottom: 1 }}>{p.n}</div>
                        <div className="mute mono" style={{ fontSize: 10 }}>{p.role}</div>
                        <div style={{ fontSize: 10.5, color: "var(--blue)", marginTop: 3 }}>{p.why}</div>
                      </div>
                      <div className="mono" style={{ fontSize: 10, color: "var(--blue)" }}>{p.m}%</div>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Bottom strip — career graph teaser + opportunities */}
            <div style={{ display: "grid", gridTemplateColumns: "1.4fr 1fr", gap: 20, marginTop: 24 }}>
              <div className="panel">
                <div className="panel-head">
                  <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                    <NumCap n={4} />
                    <h3>Your career graph <span className="mute mono" style={{ fontSize: 10, marginLeft: 6 }}>preview</span></h3>
                  </div>
                  <button className="btn sm ghost">Open profile <Icon name="arrowR" size={12} /></button>
                </div>
                <div className="panel-body" style={{ paddingTop: 24, paddingBottom: 24 }}>
                  <CareerMini />
                </div>
              </div>
              <div className="panel" style={{ background: "var(--bg-2)" }}>
                <div className="panel-head">
                  <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                    <NumCap n={5} />
                    <h3>Opportunities roadmap</h3>
                  </div>
                  <Pill tone="warm" dot>2 new</Pill>
                </div>
                <div className="panel-body">
                  <div className="serif" style={{ fontSize: 22, lineHeight: 1.2, marginBottom: 12 }}>
                    "Apply to <span style={{ color: "var(--warm)" }}>2 NIS scholarships</span> before<br /> June 1 — your profile fits 88%."
                  </div>
                  <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
                    <Pill>Open to ML internships</Pill>
                    <Pill>Almaty / remote</Pill>
                    <Pill>Y3 — Software Eng</Pill>
                  </div>
                  <button className="btn blue" style={{ marginTop: 14 }}>See full roadmap <Icon name="arrowR" size={12} /></button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// small career line (used in dashboard preview)
function CareerMini() {
  const W = 760, H = 130;
  const pts = [
    { x: 50, y: 90, label: "Y1 · 2022", role: "AITU enrolled" },
    { x: 200, y: 80, label: "Y2 · 2023", role: "Intern · BTS Digital" },
    { x: 360, y: 60, label: "Y3 · 2024", role: "Junior Dev · Kolesa" },
    { x: 520, y: 45, label: "Y3 · 2025", role: "Mentor · CodeStarter" },
    { x: 680, y: 30, label: "Now", role: "ML internships ↗", future: true },
  ];
  const path = pts.map((p, i) => `${i ? "L" : "M"} ${p.x} ${p.y}`).join(" ");
  return (
    <svg viewBox={`0 0 ${W} ${H}`} width="100%" height={H}>
      <line x1="20" y1={H - 20} x2={W - 20} y2={H - 20} className="career-track" />
      <path d={path} className="career-line" />
      {pts.map((p, i) => (
        <g key={i} className="career-node">
          <circle cx={p.x} cy={p.y} r={p.future ? 7 : 5} className="outer"
                  strokeDasharray={p.future ? "2 2" : ""} />
          {!p.future && <circle cx={p.x} cy={p.y} r={2} className="inner" />}
          <line x1={p.x} y1={H - 20} x2={p.x} y2={H - 14} className="career-tick" />
          <text x={p.x} y={H - 4} fill="var(--ink-3)" fontFamily="var(--mono)" fontSize="9" textAnchor="middle">{p.label}</text>
          <text x={p.x} y={p.y - 12} fill={p.future ? "var(--warm)" : "var(--ink-2)"} fontFamily="var(--sans)" fontSize="11" textAnchor="middle">{p.role}</text>
        </g>
      ))}
    </svg>
  );
}

window.Dashboard = Dashboard;
