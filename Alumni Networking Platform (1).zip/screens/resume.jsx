// Resume Import — multi-stage flow shown as a single overview screen
function ResumeImport() {
  return (
    <div className="aitu" data-screen-label="Resume Import">
      <Rail active="home" />
      <div className="stage">
        <Topbar crumb={["Profile", "Resume import", "Session #4f2a"]} />
        <div className="body" style={{ flexDirection: "column", overflow: "hidden" }}>
          <div style={{ flex: 1, overflowY: "auto", padding: "28px 36px 36px" }}>

            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline", marginBottom: 24 }}>
              <div>
                <div className="eyebrow" style={{ marginBottom: 10 }}>RESUME IMPORT · STEP 3 OF 4</div>
                <div className="h1" style={{ fontSize: 32 }}>We pulled <i>23 fields</i> from your PDF.<br />Confirm what's right.</div>
              </div>
              <div style={{ display: "flex", gap: 8 }}>
                <button className="btn">Save draft</button>
                <button className="btn primary">Confirm & sync to profile <Icon name="arrowR" size={12} /></button>
              </div>
            </div>

            {/* Step indicator */}
            <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 10, marginBottom: 28 }}>
              {[
                { k: "Upload", st: "done" },
                { k: "OCR + extract", st: "done" },
                { k: "Review draft", st: "current" },
                { k: "Sync to career graph", st: "next" },
              ].map((s, i) => (
                <div key={i} style={{
                  padding: "12px 14px",
                  borderRadius: 8,
                  background: s.st === "current" ? "var(--blue-soft)" : "var(--bg-2)",
                  border: "1px solid " + (s.st === "current" ? "var(--blue-line)" : "var(--line-soft)"),
                }}>
                  <div className="mono" style={{ fontSize: 10, color: s.st === "current" ? "var(--blue)" : "var(--ink-3)", marginBottom: 4 }}>
                    {String(i + 1).padStart(2, "0")} {s.st === "done" ? "✓" : ""}
                  </div>
                  <div style={{ fontSize: 13, color: s.st === "next" ? "var(--ink-3)" : "var(--ink)" }}>{s.k}</div>
                </div>
              ))}
            </div>

            {/* Two-pane: doc preview + extracted draft */}
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1.4fr", gap: 20 }}>

              {/* Document preview */}
              <div className="panel" style={{ padding: 0, overflow: "hidden", background: "var(--bg-2)" }}>
                <div style={{ padding: "12px 14px", borderBottom: "1px solid var(--line-soft)", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
                  <div className="mono" style={{ fontSize: 10.5, color: "var(--ink-2)" }}>aizhan-kuanysh-cv.pdf · 2 pages</div>
                  <div style={{ display: "flex", gap: 4 }}>
                    <button className="iconbtn"><Icon name="arrowU" size={12} /></button>
                    <span className="mono" style={{ fontSize: 10.5, color: "var(--ink-3)", alignSelf: "center" }}>1/2</span>
                    <button className="iconbtn"><Icon name="arrowD" size={12} /></button>
                  </div>
                </div>

                <div style={{ padding: 14, height: 540, overflow: "hidden", position: "relative" }}>
                  <DocPreview />
                </div>

                <div style={{ padding: "10px 14px", borderTop: "1px solid var(--line-soft)", display: "flex", alignItems: "center", gap: 8 }}>
                  <Pill tone="ok" dot>OCR done</Pill>
                  <Pill>NER · 3 entities flagged</Pill>
                  <span className="mono mute" style={{ fontSize: 10, marginLeft: "auto" }}>conf 0.87 avg</span>
                </div>
              </div>

              {/* Extracted draft */}
              <div>
                <Section name="01 · Identity" tag="auto-filled">
                  <KV k="Full name" v="Aizhan Kuanysh" conf={0.99} />
                  <KV k="Headline" v="Y3 SE student · ML/backend interest" conf={0.91} editable />
                  <KV k="Location" v="Almaty, Kazakhstan" conf={0.95} />
                  <KV k="Email" v="aizhan.k@aitu.edu.kz" conf={0.99} />
                </Section>

                <Section name="02 · Education" tag="1 record">
                  <Card>
                    <div className="h3">Astana IT University</div>
                    <div className="mute mono" style={{ fontSize: 10.5, marginTop: 2 }}>BSC · SOFTWARE ENGINEERING · 2022—2026</div>
                    <div style={{ display: "flex", gap: 6, marginTop: 8 }}>
                      <Pill tone="ok" dot>Verified · matches AITU registry</Pill>
                    </div>
                  </Card>
                </Section>

                <Section name="03 · Experience" tag="2 records · review needed">
                  <Card warn>
                    <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                      <div className="h3">Backend Intern · BTS Digital</div>
                      <Pill tone="warm">conf 0.72 · review</Pill>
                    </div>
                    <div className="mute mono" style={{ fontSize: 10.5, marginTop: 2 }}>JUN 2024 — SEP 2024 · 4 MONTHS</div>
                    <div className="dim" style={{ fontSize: 12, marginTop: 8 }}>Built internal billing dashboard in Go + React. Cut report generation from 8s → 0.6s.</div>
                    <div className="mono" style={{ fontSize: 10, color: "var(--warm)", marginTop: 8 }}>⚠ Could not match company in alumni registry — please confirm.</div>
                  </Card>
                  <Card>
                    <div className="h3">Teaching Assistant · CS101</div>
                    <div className="mute mono" style={{ fontSize: 10.5, marginTop: 2 }}>SEP 2024 — NOW · 8 MONTHS · AITU</div>
                  </Card>
                </Section>

                <Section name="04 · Skills" tag="14 detected">
                  <div style={{ display: "flex", flexWrap: "wrap", gap: 5 }}>
                    {[
                      ["Python", 0.97], ["Go", 0.93], ["PyTorch", 0.91], ["FastAPI", 0.89],
                      ["PostgreSQL", 0.86], ["Docker", 0.84], ["React", 0.81], ["Linux", 0.78],
                      ["TensorFlow", 0.66], ["AWS", 0.61],
                    ].map(([s, c]) => (
                      <span key={s} className="chip skill" style={{
                        background: c < 0.7 ? "rgba(216,165,116,0.12)" : "var(--surface)",
                        borderColor: c < 0.7 ? "rgba(216,165,116,0.32)" : "var(--line)",
                        color: c < 0.7 ? "var(--warm)" : "var(--ink-2)",
                      }}>
                        {s} <span className="mono" style={{ fontSize: 9, opacity: 0.7, marginLeft: 4 }}>{c.toFixed(2)}</span>
                      </span>
                    ))}
                    <button className="chip skill" style={{ borderStyle: "dashed", color: "var(--ink-3)" }}>+ add</button>
                  </div>
                </Section>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function Section({ name, tag, children }) {
  return (
    <div style={{ marginBottom: 18 }}>
      <div style={{ display: "flex", alignItems: "baseline", gap: 10, marginBottom: 10 }}>
        <div className="eyebrow">{name}</div>
        {tag && <span className="mono mute" style={{ fontSize: 10 }}>· {tag}</span>}
      </div>
      <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
        {children}
      </div>
    </div>
  );
}
function KV({ k, v, conf, editable }) {
  return (
    <div className="panel" style={{ padding: "10px 14px", display: "grid", gridTemplateColumns: "120px 1fr auto", gap: 12, alignItems: "center" }}>
      <div className="mono" style={{ fontSize: 10.5, color: "var(--ink-3)", letterSpacing: "0.04em" }}>{k.toUpperCase()}</div>
      <div style={{ fontSize: 13, color: "var(--ink)" }}>
        {v}
        {editable && <span className="mute mono" style={{ marginLeft: 8, fontSize: 10 }}>· edit</span>}
      </div>
      <span className="mono" style={{ fontSize: 10, color: conf > 0.9 ? "var(--ok)" : conf > 0.75 ? "var(--ink-3)" : "var(--warm)" }}>{conf.toFixed(2)}</span>
    </div>
  );
}
function Card({ warn, children }) {
  return (
    <div className="panel" style={{ padding: 14, borderColor: warn ? "rgba(216,165,116,0.32)" : "var(--line-soft)", background: warn ? "rgba(216,165,116,0.04)" : "var(--surface)" }}>
      {children}
    </div>
  );
}

// faux PDF preview
function DocPreview() {
  const lines = [
    { t: "AIZHAN KUANYSH", w: 60, big: true },
    { t: "almaty · aizhan.k@aitu.edu.kz · linkedin.com/in/aizhank", w: 70, mute: true },
    { t: "EDUCATION", w: 30, eyebrow: true },
    { t: "Astana IT University · BSc Software Engineering", w: 78, hl: 1 },
    { t: "2022 — 2026 · GPA 3.74 · Almaty", w: 50, mute: true, hl: 1 },
    { t: "EXPERIENCE", w: 30, eyebrow: true },
    { t: "Backend Intern · BTS Digital", w: 60, hl: 2 },
    { t: "Jun 2024 — Sep 2024", w: 36, mute: true, hl: 2 },
    { t: "— Built internal billing dashboard in Go + React", w: 80 },
    { t: "— Cut report generation from 8s → 0.6s", w: 70 },
    { t: "Teaching Assistant · CS101", w: 50, hl: 2 },
    { t: "Sep 2024 — Now", w: 30, mute: true, hl: 2 },
    { t: "SKILLS", w: 22, eyebrow: true },
    { t: "Python · Go · PyTorch · FastAPI · React · Postgres", w: 90, hl: 4 },
    { t: "Docker · Linux · AWS · TensorFlow", w: 60, hl: 4 },
  ];
  return (
    <div style={{
      width: "100%", height: "100%",
      background: "#f5f1ea",
      color: "#2a251f",
      borderRadius: 4,
      padding: "32px 28px",
      fontFamily: "ui-serif, Georgia, serif",
      position: "relative",
      overflow: "hidden",
    }}>
      {lines.map((l, i) => (
        <div key={i} style={{
          marginBottom: l.eyebrow ? 6 : (l.big ? 6 : 4),
          marginTop: l.eyebrow ? 14 : 0,
          height: l.big ? 16 : 8,
          width: `${l.w}%`,
          background: l.eyebrow
            ? "rgba(60,50,40,0.55)"
            : l.mute
              ? "rgba(60,50,40,0.32)"
              : "rgba(60,50,40,0.78)",
          borderRadius: 2,
          position: "relative",
          opacity: l.eyebrow ? 0.85 : 1,
          fontSize: 0,
          // highlight overlay
          boxShadow: l.hl ? `0 0 0 4px ${["", "rgba(75,166,220,0.16)", "rgba(216,165,116,0.20)", "", "rgba(75,166,220,0.10)"][l.hl]}` : "none",
        }} />
      ))}
      {/* annotation pin */}
      <div style={{ position: "absolute", right: 18, top: 130, padding: "4px 8px", background: "var(--blue)", color: "var(--bg)", borderRadius: 4, fontFamily: "var(--mono)", fontSize: 10, transform: "translateX(20%)" }}>
        education · matched
      </div>
      <div style={{ position: "absolute", right: 18, top: 200, padding: "4px 8px", background: "var(--warm)", color: "#1a1410", borderRadius: 4, fontFamily: "var(--mono)", fontSize: 10, transform: "translateX(20%)" }}>
        review · 0.72
      </div>
    </div>
  );
}

window.ResumeImport = ResumeImport;
