// Profile — public profile + career trajectory graph (signature feature)
function Profile() {
  return (
    <div className="aitu" data-screen-label="Profile">
      <Rail active="home" />
      <div className="stage">
        <Topbar crumb={["Directory", "Madiyar Toleu"]} />
        <div className="body" style={{ flexDirection: "column", overflow: "hidden" }}>
          <div style={{ flex: 1, overflowY: "auto" }}>

            {/* Cover */}
            <div style={{ height: 140, position: "relative", borderBottom: "1px solid var(--line-soft)",
                          background: "radial-gradient(800px 200px at 70% -20%, rgba(75,166,220,0.18), transparent 60%), repeating-linear-gradient(-45deg, rgba(216,165,116,0.05) 0 8px, transparent 8px 16px), var(--bg-2)" }}>
              <div style={{ position: "absolute", right: 24, top: 16, display: "flex", gap: 6 }}>
                <button className="btn sm ghost"><Icon name="link" size={12} /> Share</button>
                <button className="btn sm">Edit cover</button>
              </div>
              <div style={{ position: "absolute", left: 24, bottom: 12, opacity: 0.4 }}>
                <AituGlyph size={42} color="#5a5650" accent="#3b6e8f" />
              </div>
            </div>

            {/* Identity bar */}
            <div style={{ padding: "0 36px", marginTop: -38, position: "relative" }}>
              <div style={{ display: "grid", gridTemplateColumns: "auto 1fr auto", gap: 20, alignItems: "end" }}>
                <div style={{ width: 96, height: 96, borderRadius: 16, background: "var(--bg)", padding: 4 }}>
                  <div className="avatar xl" style={{ width: "100%", height: "100%", borderRadius: 12, background: "#3a3a48", color: "#d6d2c2" }}>MT</div>
                </div>
                <div style={{ paddingBottom: 8 }}>
                  <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 6 }}>
                    <div className="h2">Madiyar Toleu</div>
                    <Pill tone="blue" dot>Mentor · accepting</Pill>
                    <Pill tone="warm">Alumni · 2018</Pill>
                  </div>
                  <div className="dim" style={{ fontSize: 14, marginBottom: 8, maxWidth: 620 }}>
                    Senior Software Engineer at Kaspi.kz. Helping students break into backend & systems. <span className="serif" style={{ color: "var(--warm)" }}>"Ship boring infra, then ship more."</span>
                  </div>
                  <div style={{ display: "flex", alignItems: "center", gap: 14, color: "var(--ink-3)", fontSize: 12 }} className="mono">
                    <span>ALMATY · KZ</span>
                    <span>·</span>
                    <span>SOFTWARE ENG · CLASS OF '18</span>
                    <span>·</span>
                    <span style={{ color: "var(--blue)" }}>★ 4.9 · 32 mentees</span>
                  </div>
                </div>
                <div style={{ display: "flex", gap: 6, paddingBottom: 8 }}>
                  <button className="btn"><Icon name="msg" size={14} /> Message</button>
                  <button className="btn"><Icon name="link" size={14} /> Connect</button>
                  <button className="btn primary"><Icon name="spark" size={14} /> Request mentorship</button>
                </div>
              </div>

              {/* Tabs */}
              <div className="tabs" style={{ marginTop: 22 }}>
                <div className="tab active">Trajectory</div>
                <div className="tab">About</div>
                <div className="tab">Mentees <span className="count">32</span></div>
                <div className="tab">Posts <span className="count">14</span></div>
                <div className="tab">Reviews <span className="count">28</span></div>
              </div>
            </div>

            {/* Career trajectory — full width signature view */}
            <div style={{ padding: "28px 36px 12px" }}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline", marginBottom: 18 }}>
                <div>
                  <div className="eyebrow" style={{ marginBottom: 8 }}>01 · CAREER TRAJECTORY</div>
                  <div className="h1" style={{ fontSize: 28 }}>From <i>AITU</i> to <span style={{ color: "var(--blue)" }}>principal-track</span> in <i>7 years</i>.</div>
                </div>
                <div style={{ display: "flex", gap: 8 }}>
                  <Pill>Verified · resume import</Pill>
                  <Pill>Tap nodes to inspect</Pill>
                </div>
              </div>

              <div className="panel" style={{ padding: "32px 28px 24px", background: "var(--bg-2)" }}>
                <CareerFull />
              </div>
            </div>

            {/* Lower grid: skills · education · experience · sidebar */}
            <div style={{ padding: "20px 36px 36px", display: "grid", gridTemplateColumns: "2fr 1fr", gap: 24 }}>
              <div>
                <div className="eyebrow" style={{ marginBottom: 12 }}>02 · EXPERIENCE</div>
                <div style={{ display: "flex", flexDirection: "column", gap: 1, background: "var(--line-soft)", border: "1px solid var(--line-soft)", borderRadius: 10, overflow: "hidden" }}>
                  {[
                    { co: "Kaspi.kz", role: "Senior Software Engineer", time: "2023 — Now · 2y 4m", body: "Payments infra · Kotlin / JVM. Mentoring 6 juniors on ramp-up.", tag: "current" },
                    { co: "Beeline KZ", role: "Software Engineer", time: "2020 — 2023 · 3y", body: "Built telecom CDR pipeline; led migration from monolith to event-driven services.", tag: null },
                    { co: "Higgsfield AI", role: "Backend Intern", time: "2019 — 2020 · 1y", body: "First job out of AITU — internal data tools.", tag: null },
                  ].map((j, i) => (
                    <div key={i} style={{ background: "var(--surface)", padding: "16px 18px", display: "grid", gridTemplateColumns: "auto 1fr", gap: 14 }}>
                      <div style={{ width: 40, height: 40, borderRadius: 8, background: "var(--bg-2)", border: "1px solid var(--line)", display: "grid", placeItems: "center", color: "var(--ink-2)" }} className="mono">
                        {j.co.slice(0, 2).toUpperCase()}
                      </div>
                      <div>
                        <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 2 }}>
                          <div className="h3">{j.role}</div>
                          {j.tag && <Pill tone="ok" dot>{j.tag}</Pill>}
                        </div>
                        <div className="mute" style={{ fontSize: 12 }}>
                          <span>{j.co}</span><span className="dot-sep" /><span className="mono">{j.time}</span>
                        </div>
                        <div className="dim" style={{ fontSize: 13, marginTop: 8, maxWidth: 640 }}>{j.body}</div>
                      </div>
                    </div>
                  ))}
                </div>

                <div className="eyebrow" style={{ margin: "28px 0 12px" }}>03 · EDUCATION</div>
                <div className="panel" style={{ padding: "16px 18px", display: "grid", gridTemplateColumns: "auto 1fr auto", gap: 14, alignItems: "center" }}>
                  <div style={{ width: 40, height: 40, borderRadius: 8, background: "var(--ink)", color: "var(--bg)", display: "grid", placeItems: "center", fontFamily: "var(--mono)", fontWeight: 700 }}>
                    <AituGlyph size={26} color="#0c0e10" accent="#2b7bb8" />
                  </div>
                  <div>
                    <div className="h3">Astana IT University</div>
                    <div className="mute" style={{ fontSize: 12 }}>BSc · Software Engineering · GPA 3.86</div>
                  </div>
                  <div className="mono mute" style={{ fontSize: 11 }}>2014 — 2018</div>
                </div>
              </div>

              <div>
                <div className="eyebrow" style={{ marginBottom: 12 }}>04 · MENTORSHIP CAPACITY</div>
                <div className="panel" style={{ padding: 16 }}>
                  <div style={{ display: "flex", alignItems: "baseline", justifyContent: "space-between", marginBottom: 10 }}>
                    <div className="mono" style={{ fontSize: 11, color: "var(--ink-3)" }}>4 / 6 ACTIVE</div>
                    <div className="mono" style={{ fontSize: 11, color: "var(--ok)" }}>2 SLOTS OPEN</div>
                  </div>
                  <div style={{ display: "grid", gridTemplateColumns: "repeat(6, 1fr)", gap: 4 }}>
                    {Array.from({ length: 6 }).map((_, i) => (
                      <div key={i} style={{ height: 28, borderRadius: 4, background: i < 4 ? "var(--blue)" : "var(--surface-2)", border: "1px solid " + (i < 4 ? "var(--blue)" : "var(--line)") }} />
                    ))}
                  </div>
                  <div style={{ fontSize: 12, color: "var(--ink-2)", marginTop: 12 }}>
                    Helps with: <span style={{ color: "var(--ink)" }}>Backend, Distributed systems, Career transitions, Interview prep</span>
                  </div>
                </div>

                <div className="eyebrow" style={{ margin: "20px 0 12px" }}>05 · SKILLS</div>
                <div style={{ display: "flex", flexWrap: "wrap", gap: 6 }}>
                  {["Kotlin", "JVM", "PostgreSQL", "Kafka", "Distributed systems", "gRPC", "AWS", "K8s", "Mentoring", "System design"].map(s => (
                    <span key={s} className="chip skill">{s}</span>
                  ))}
                </div>

                <div className="eyebrow" style={{ margin: "20px 0 12px" }}>06 · LATEST REVIEW</div>
                <div className="panel" style={{ padding: 16 }}>
                  <div className="serif" style={{ fontSize: 17, lineHeight: 1.35, color: "var(--ink)" }}>
                    "Madiyar pushed me to ship a real distributed system in 8 weeks. I now lead infra at my new job."
                  </div>
                  <div style={{ display: "flex", alignItems: "center", gap: 10, marginTop: 12 }}>
                    <Avatar name="Asem K" tone="b6" size="s" />
                    <div className="mono" style={{ fontSize: 11 }}>
                      <span style={{ color: "var(--ink-2)" }}>ASEM K.</span>
                      <span className="mute"> · 2025 · ★★★★★</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// Full career trajectory — multi-track graph: education / employment / mentorship / projects
function CareerFull() {
  const W = 1180, H = 280;
  const tracks = [
    { y: 60, label: "EDUCATION", color: "var(--warm)" },
    { y: 130, label: "EMPLOYMENT", color: "var(--blue)" },
    { y: 200, label: "MENTORSHIP", color: "var(--ok)" },
    { y: 250, label: "PROJECTS", color: "var(--ink-3)" },
  ];
  const years = [2014, 2016, 2018, 2020, 2022, 2024, 2026];
  const xOf = y => 80 + ((y - 2014) / (2026 - 2014)) * (W - 120);

  const segments = [
    // education
    { track: 0, from: 2014, to: 2018, label: "AITU · BSc Software Eng", weight: 1 },
    { track: 0, from: 2022, to: 2023, label: "AWS Solutions Architect", weight: 0.5 },
    // employment
    { track: 1, from: 2019, to: 2020, label: "Higgsfield · Intern", weight: 0.6 },
    { track: 1, from: 2020, to: 2023, label: "Beeline KZ · SWE", weight: 1 },
    { track: 1, from: 2023, to: 2026, label: "Kaspi.kz · Senior SWE", weight: 1.4, current: true },
    // mentorship
    { track: 2, from: 2022, to: 2026, label: "AITU mentor · 32 mentees", weight: 1, dotted: true },
    // projects
    { track: 3, from: 2021, to: 2022, label: "kafka-trace OSS", weight: 0.6 },
    { track: 3, from: 2024, to: 2025, label: "qdrant-pgsync", weight: 0.6 },
  ];

  const events = [
    { y: 2014, t: "AITU enrolled", track: 0 },
    { y: 2018, t: "BSc graduate", track: 0, big: true },
    { y: 2020, t: "First full-time", track: 1, big: true },
    { y: 2023, t: "Senior promotion", track: 1, big: true },
    { y: 2024, t: "First mentee · Asem", track: 2 },
  ];

  return (
    <svg viewBox={`0 0 ${W} ${H}`} width="100%" height={H}>
      {/* year ticks */}
      {years.map(y => (
        <g key={y}>
          <line x1={xOf(y)} y1={20} x2={xOf(y)} y2={H - 24} stroke="var(--line-soft)" strokeDasharray="2 4" />
          <text x={xOf(y)} y={H - 8} fill="var(--ink-3)" fontFamily="var(--mono)" fontSize="9" textAnchor="middle">{y}</text>
        </g>
      ))}
      {/* tracks */}
      {tracks.map((tr, i) => (
        <g key={i}>
          <line x1={60} y1={tr.y} x2={W - 30} y2={tr.y} stroke="var(--line)" strokeWidth="1" />
          <text x={50} y={tr.y + 3} fill="var(--ink-3)" fontFamily="var(--mono)" fontSize="9" textAnchor="end">{tr.label}</text>
        </g>
      ))}
      {/* segments */}
      {segments.map((s, i) => {
        const tr = tracks[s.track];
        const x1 = xOf(s.from), x2 = xOf(s.to);
        const h = 6 + s.weight * 6;
        return (
          <g key={i}>
            <rect x={x1} y={tr.y - h / 2} width={x2 - x1} height={h} rx={h / 2}
                  fill={s.dotted ? "transparent" : tr.color}
                  stroke={tr.color}
                  strokeDasharray={s.dotted ? "3 3" : "0"}
                  opacity={s.current ? 1 : 0.85} />
            <text x={x1 + 6} y={tr.y - h / 2 - 6} fill="var(--ink-2)" fontFamily="var(--sans)" fontSize="11">{s.label}</text>
          </g>
        );
      })}
      {/* event markers */}
      {events.map((e, i) => {
        const tr = tracks[e.track];
        return (
          <g key={i}>
            <circle cx={xOf(e.y)} cy={tr.y} r={e.big ? 6 : 4} fill="var(--bg-2)" stroke={tr.color} strokeWidth="1.5" />
            {e.big && <circle cx={xOf(e.y)} cy={tr.y} r={2} fill={tr.color} />}
          </g>
        );
      })}
      {/* "now" line */}
      <line x1={xOf(2026)} y1={20} x2={xOf(2026)} y2={H - 24} stroke="var(--blue)" strokeWidth="1" strokeDasharray="0" />
      <text x={xOf(2026) + 6} y={28} fill="var(--blue)" fontFamily="var(--mono)" fontSize="9">NOW</text>
    </svg>
  );
}

window.Profile = Profile;
