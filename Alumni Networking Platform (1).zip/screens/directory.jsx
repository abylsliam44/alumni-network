// Directory + Connections — search/filter people, with split-pane preview
function Directory() {
  const people = [
    { n: "Madina Aldiyar", t: "b4", role: "Senior PM", co: "Beeline KZ", grad: "'19", loc: "Almaty", skills: ["Product", "ML", "Strategy"], match: 94, mentor: true, status: null },
    { n: "Ruslan Oraz", t: "b8", role: "Founder", co: "Codify", grad: "'17", loc: "Astana", skills: ["Backend", "Hiring"], match: 91, mentor: true, status: "connected" },
    { n: "Tomiris Bek", t: "b5", role: "ML Engineer", co: "Higgsfield", grad: "'21", loc: "Almaty", skills: ["PyTorch", "MLOps", "Kaggle"], match: 87, mentor: false, status: null },
    { n: "Daniyar Bekov", t: "b2", role: "Y3 Student", co: "AITU", grad: "'27", loc: "Astana", skills: ["Backend", "Go"], match: 82, mentor: false, status: "pending" },
    { n: "Aisha Nurlan", t: "b6", role: "iOS Engineer", co: "Halyk Tech", grad: "'20", loc: "Almaty", skills: ["Swift", "UIKit"], match: 79, mentor: true, status: null },
    { n: "Erlan Tursyn", t: "b3", role: "Y2 Student", co: "AITU", grad: "'28", loc: "Almaty", skills: ["Data Science"], match: 74, mentor: false, status: null },
  ];
  return (
    <div className="aitu" data-screen-label="Directory">
      <Rail active="directory" />
      <div className="stage">
        <Topbar crumb={["Network", "Directory"]} />
        <div className="body" style={{ flexDirection: "row", overflow: "hidden" }}>

          {/* Filter rail */}
          <div style={{ width: 260, flex: "0 0 260px", borderRight: "1px solid var(--line-soft)", padding: "20px 18px", overflowY: "auto" }}>
            <div className="eyebrow" style={{ marginBottom: 14 }}>FILTERS</div>

            <div style={{ position: "relative", marginBottom: 16 }}>
              <input className="input" placeholder="Search by name, skill, company…" style={{ paddingLeft: 30 }} />
              <div style={{ position: "absolute", left: 10, top: 9, color: "var(--ink-3)" }}><Icon name="search" size={14} /></div>
            </div>

            <FilterGroup label="Role" items={[
              { k: "Alumni", n: 1284, on: true },
              { k: "Student", n: 3142, on: false },
              { k: "Staff", n: 86, on: false },
            ]} />

            <FilterGroup label="Mentor" items={[
              { k: "Accepting mentees", n: 134, on: true, blue: true },
              { k: "Currently full", n: 42 },
            ]} />

            <FilterGroup label="Graduation year" items={[
              { k: "2017—2019", n: 286 },
              { k: "2020—2022", n: 412, on: true },
              { k: "2023—2025", n: 386 },
            ]} />

            <FilterGroup label="Location" items={[
              { k: "Almaty", n: 612, on: true },
              { k: "Astana", n: 458 },
              { k: "Remote / global", n: 214 },
            ]} />

            <div className="eyebrow" style={{ margin: "20px 0 10px" }}>SKILLS</div>
            <div style={{ display: "flex", flexWrap: "wrap", gap: 6 }}>
              {["Backend", "ML", "Product", "Frontend", "Mobile", "Data", "Design", "Security"].map((s, i) => (
                <span key={s} className="chip skill" style={i < 2 ? { background: "var(--blue-soft)", borderColor: "var(--blue-line)", color: "var(--blue)" } : {}}>
                  {s}
                </span>
              ))}
            </div>
          </div>

          {/* Results */}
          <div style={{ flex: 1, minWidth: 0, display: "flex", flexDirection: "column" }}>
            <div style={{ padding: "20px 28px 14px", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
              <div>
                <div className="eyebrow" style={{ marginBottom: 6 }}>1284 ALUMNI · 134 ACCEPTING MENTEES</div>
                <div className="h2">Find your <i>people</i>.</div>
              </div>
              <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
                <Pill tone="blue" dot>Sorted by AI match</Pill>
                <button className="btn sm"><Icon name="sliders" size={12} /> Sort</button>
              </div>
            </div>

            {/* Active filter chips */}
            <div style={{ padding: "0 28px 14px", display: "flex", gap: 6, flexWrap: "wrap" }}>
              <ActiveChip label="Alumni" />
              <ActiveChip label="Accepting mentees" tone="blue" />
              <ActiveChip label="Almaty" />
              <ActiveChip label="2020—2022" />
              <ActiveChip label="Backend" />
              <ActiveChip label="ML" />
              <span className="mute mono" style={{ fontSize: 10.5, alignSelf: "center", marginLeft: 4 }}>· clear all</span>
            </div>

            <div style={{ flex: 1, overflowY: "auto", padding: "0 28px 28px", display: "grid", gridTemplateColumns: "repeat(2, 1fr)", gap: 12, alignContent: "start" }}>
              {people.map((p, i) => (
                <div key={i} className="panel" style={{ padding: 16, display: "grid", gridTemplateColumns: "auto 1fr", gap: 14, position: "relative", borderColor: i === 0 ? "var(--blue-line)" : "var(--line-soft)" }}>
                  {i === 0 && (
                    <div style={{ position: "absolute", top: -1, right: 14, padding: "2px 8px", background: "var(--blue)", color: "var(--bg)", fontFamily: "var(--mono)", fontSize: 9, letterSpacing: "0.06em", borderRadius: "0 0 4px 4px" }}>
                      TOP MATCH · {p.match}%
                    </div>
                  )}
                  <Avatar name={p.n} tone={p.t} size="l" />
                  <div style={{ minWidth: 0 }}>
                    <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 4 }}>
                      <div className="h3">{p.n}</div>
                      {p.mentor && <Pill tone="blue" dot>Mentor</Pill>}
                      {p.status === "connected" && <Pill tone="ok" dot>Connected</Pill>}
                      {p.status === "pending" && <Pill>Pending</Pill>}
                    </div>
                    <div className="dim" style={{ fontSize: 13 }}>{p.role} · {p.co}</div>
                    <div className="mute mono" style={{ fontSize: 10.5, marginTop: 4 }}>
                      AITU {p.grad} · {p.loc} {i !== 0 && <span style={{ color: "var(--blue)", marginLeft: 6 }}>· {p.match}%</span>}
                    </div>
                    <div style={{ display: "flex", flexWrap: "wrap", gap: 4, marginTop: 10 }}>
                      {p.skills.map(s => <span key={s} className="chip skill">{s}</span>)}
                    </div>
                    <div style={{ display: "flex", gap: 6, marginTop: 12 }}>
                      <button className="btn sm">Message</button>
                      {p.status !== "connected"
                        ? <button className="btn sm primary">+ Connect</button>
                        : <button className="btn sm ghost">View profile →</button>}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function FilterGroup({ label, items }) {
  return (
    <div style={{ marginBottom: 16 }}>
      <div className="eyebrow" style={{ marginBottom: 8 }}>{label}</div>
      <div style={{ display: "flex", flexDirection: "column", gap: 4 }}>
        {items.map((it, i) => (
          <label key={i} style={{ display: "flex", alignItems: "center", gap: 8, fontSize: 12.5, color: it.on ? "var(--ink)" : "var(--ink-2)", cursor: "pointer" }}>
            <span style={{
              width: 14, height: 14, borderRadius: 3,
              border: "1px solid " + (it.on ? (it.blue ? "var(--blue)" : "var(--ink-2)") : "var(--line)"),
              background: it.on ? (it.blue ? "var(--blue)" : "var(--ink-2)") : "transparent",
              display: "grid", placeItems: "center", color: "var(--bg)",
            }}>
              {it.on && <Icon name="check" size={10} />}
            </span>
            <span style={{ flex: 1 }}>{it.k}</span>
            <span className="mono mute" style={{ fontSize: 10 }}>{it.n}</span>
          </label>
        ))}
      </div>
    </div>
  );
}
function ActiveChip({ label, tone }) {
  return (
    <span className={`chip${tone === "blue" ? "" : ""}`} style={{
      display: "inline-flex", alignItems: "center", gap: 6,
      background: tone === "blue" ? "var(--blue-soft)" : "var(--surface)",
      borderColor: tone === "blue" ? "var(--blue-line)" : "var(--line)",
      color: tone === "blue" ? "var(--blue)" : "var(--ink-2)",
      fontSize: 11,
    }}>
      {label}
      <Icon name="close" size={10} />
    </span>
  );
}
window.Directory = Directory;
