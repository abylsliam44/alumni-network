// AqyldyAI — chat assistant for the platform with knowledge base
function AiChat() {
  return (
    <div className="aitu" data-screen-label="AqyldyAI">
      <Rail active="ai" />
      <div className="stage">
        <Topbar crumb={["AqyldyAI", "New conversation"]} />
        <div className="body" style={{ flexDirection: "row", overflow: "hidden" }}>

          {/* History rail */}
          <div style={{ width: 240, flex: "0 0 240px", borderRight: "1px solid var(--line-soft)", padding: "16px 12px", overflowY: "auto", display: "flex", flexDirection: "column", gap: 4 }}>
            <button className="btn primary" style={{ marginBottom: 12, justifyContent: "center" }}><Icon name="plus" size={12} /> New chat</button>
            <div className="eyebrow" style={{ padding: "0 8px", marginBottom: 8 }}>TODAY</div>
            {[
              { t: "Paths after AITU CS", on: true },
              { t: "Mentorship etiquette" },
            ].map((c, i) => (
              <div key={i} style={{ padding: "8px 10px", borderRadius: 6, background: c.on ? "var(--surface)" : "transparent", color: c.on ? "var(--ink)" : "var(--ink-2)", fontSize: 12.5, cursor: "pointer", display: "flex", alignItems: "center", gap: 8 }}>
                <Icon name="msg" size={12} />
                <span style={{ flex: 1, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{c.t}</span>
              </div>
            ))}
            <div className="eyebrow" style={{ padding: "12px 8px 8px" }}>EARLIER</div>
            {[
              "Resume bullet review",
              "How to ask for raise",
              "Internships in Almaty",
              "Kaggle prep plan",
              "Negotiation script",
            ].map((t, i) => (
              <div key={i} style={{ padding: "8px 10px", borderRadius: 6, color: "var(--ink-2)", fontSize: 12.5, cursor: "pointer", display: "flex", alignItems: "center", gap: 8 }}>
                <Icon name="msg" size={12} />
                <span style={{ flex: 1, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{t}</span>
              </div>
            ))}

            <div style={{ marginTop: "auto", padding: "12px 10px", borderTop: "1px solid var(--line-soft)" }}>
              <div className="eyebrow" style={{ marginBottom: 8 }}>KNOWLEDGE BASE</div>
              <div className="mono" style={{ fontSize: 10.5, color: "var(--ink-2)", lineHeight: 1.5 }}>
                <div>1,284 alumni profiles</div>
                <div>312 events archived</div>
                <div>78 docs · handbook</div>
                <div style={{ color: "var(--ok)", marginTop: 4 }}>● synced 4m ago</div>
              </div>
            </div>
          </div>

          {/* Conversation */}
          <div style={{ flex: 1, minWidth: 0, display: "flex", flexDirection: "column" }}>
            <div style={{ flex: 1, overflowY: "auto", padding: "32px 56px" }}>

              {/* Greeting / brand */}
              <div style={{ display: "flex", alignItems: "center", gap: 14, marginBottom: 32 }}>
                <AituGlyph size={48} color="var(--ink-2)" accent="var(--blue)" />
                <div>
                  <div className="h1" style={{ fontSize: 28 }}>AqyldyAI</div>
                  <div className="mono mute" style={{ fontSize: 11 }}>YOUR AITU CAREER COPILOT · CLAUDE-HAIKU 4.5 + RAG</div>
                </div>
              </div>

              {/* Message — user */}
              <Bubble role="user">
                What backend roles in Almaty would actually take a Y3 AITU student with Go + a couple of side projects? Be specific — companies, not vibes.
              </Bubble>

              {/* Message — assistant with sources */}
              <Bubble role="ai">
                <div style={{ marginBottom: 14 }}>
                  Based on alumni placements over the last 18 months and current openings, three companies hire Y3 students with your stack reliably:
                </div>
                <div style={{ display: "grid", gap: 10, marginBottom: 14 }}>
                  {[
                    { co: "Kaspi.kz", role: "Backend Intern · Go/Java", note: "Hired 14 AITU students in 2024–25. Mentor available: Madiyar Toleu." },
                    { co: "Kolesa Group", role: "Junior Backend · Go", note: "Open to Y3 with 1 deployed project. Asem K. is hiring manager + alumna." },
                    { co: "BTS Digital", role: "SWE Intern · Go/Python", note: "Smallest team — fastest impact. 6-week paid internship." },
                  ].map((o, i) => (
                    <div key={i} style={{ display: "grid", gridTemplateColumns: "auto 1fr auto", gap: 12, padding: "10px 12px", border: "1px solid var(--line)", borderRadius: 8, background: "var(--bg-2)", alignItems: "center" }}>
                      <div className="mono" style={{ width: 24, textAlign: "center", fontSize: 11, color: "var(--ink-3)" }}>{i + 1}</div>
                      <div>
                        <div className="h3" style={{ fontSize: 13 }}>{o.co} <span className="mute mono" style={{ marginLeft: 6, fontSize: 10 }}>{o.role}</span></div>
                        <div className="mute" style={{ fontSize: 11.5, marginTop: 2 }}>{o.note}</div>
                      </div>
                      <button className="btn sm ghost"><Icon name="external" size={12} /></button>
                    </div>
                  ))}
                </div>
                <div style={{ marginBottom: 8 }}>
                  Want me to <span style={{ color: "var(--blue)" }}>draft a cold email to Asem</span>, or build a <span style={{ color: "var(--blue)" }}>72-hour prep plan</span> for the Kolesa interview?
                </div>
                <div className="mono" style={{ fontSize: 10, color: "var(--ink-3)", marginTop: 16, paddingTop: 12, borderTop: "1px dashed var(--line-soft)" }}>
                  <span style={{ color: "var(--ink-2)" }}>SOURCES:</span>
                  <span style={{ marginLeft: 8 }}>alumni-placements-2024.csv · jobs/open · 6 alumni interviews</span>
                </div>
              </Bubble>

              {/* Suggested prompts */}
              <div style={{ display: "flex", gap: 8, marginTop: 8, flexWrap: "wrap" }}>
                {[
                  "Draft the cold email to Asem",
                  "72-hour prep plan",
                  "Compare Kolesa vs Kaspi culture",
                  "Set up resume import",
                ].map((s, i) => (
                  <button key={i} className="btn sm ghost" style={{ background: "var(--bg-2)" }}>{s}</button>
                ))}
              </div>
            </div>

            {/* Composer */}
            <div style={{ padding: "16px 56px 24px", borderTop: "1px solid var(--line-soft)" }}>
              <div style={{ position: "relative", background: "var(--surface)", border: "1px solid var(--line)", borderRadius: 12, padding: "10px 12px" }}>
                <div style={{ minHeight: 56, fontSize: 13.5, color: "var(--ink-2)", padding: "4px 4px 8px" }}>
                  Ask AqyldyAI anything about AITU alumni, careers, events, or your own profile…
                </div>
                <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
                  <button className="iconbtn"><Icon name="paper" size={14} /></button>
                  <button className="iconbtn"><Icon name="upload" size={14} /></button>
                  <Pill>@profile</Pill>
                  <Pill>@alumni</Pill>
                  <div style={{ flex: 1 }} />
                  <span className="mono mute" style={{ fontSize: 10 }}>RAG · alumni KB</span>
                  <button className="btn primary sm"><Icon name="send" size={12} /> Send</button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function Bubble({ role, children }) {
  if (role === "user") {
    return (
      <div style={{ display: "flex", justifyContent: "flex-end", marginBottom: 24 }}>
        <div style={{ maxWidth: 540, padding: "12px 16px", background: "var(--surface-2)", border: "1px solid var(--line)", borderRadius: "12px 12px 4px 12px", fontSize: 13.5, lineHeight: 1.5 }}>
          {children}
        </div>
      </div>
    );
  }
  return (
    <div style={{ display: "flex", alignItems: "flex-start", gap: 14, marginBottom: 24 }}>
      <div style={{ width: 32, height: 32, borderRadius: 8, background: "var(--bg-2)", border: "1px solid var(--line)", display: "grid", placeItems: "center", flex: "0 0 auto" }}>
        <AituGlyph size={20} color="var(--ink-2)" accent="var(--blue)" />
      </div>
      <div style={{ flex: 1, fontSize: 13.5, lineHeight: 1.55 }}>{children}</div>
    </div>
  );
}
window.AiChat = AiChat;
