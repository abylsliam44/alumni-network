// Jobs — board (left) + selected job detail (right) split view
function Jobs() {
  const list = [
    { co: "Kaspi.kz", role: "Backend Intern", tag: "Go / Java", loc: "Almaty · hybrid", time: "2d", apps: 47, status: "open", hot: true, sel: true },
    { co: "Kolesa Group", role: "Junior Backend Engineer", tag: "Go", loc: "Almaty · onsite", time: "5d", apps: 23, status: "open" },
    { co: "Higgsfield AI", role: "ML Research Intern", tag: "PyTorch", loc: "Remote · global", time: "1w", apps: 112, status: "open", hot: true },
    { co: "BTS Digital", role: "SWE Intern", tag: "Python / Go", loc: "Astana", time: "1w", apps: 18, status: "open" },
    { co: "Halyk Tech", role: "iOS Engineer", tag: "Swift", loc: "Almaty", time: "2w", apps: 9, status: "open" },
    { co: "JusanBank", role: "Backend Engineer", tag: "Kotlin / JVM", loc: "Almaty", time: "2w", apps: 31, status: "closing-soon" },
    { co: "Beeline KZ", role: "Data Engineer", tag: "Python · Spark", loc: "Almaty", time: "3w", apps: 14, status: "open" },
    { co: "Codify", role: "Founding Engineer", tag: "TS · Next.js", loc: "Astana · onsite", time: "3w", apps: 6, status: "open" },
  ];
  return (
    <div className="aitu" data-screen-label="Jobs">
      <Rail active="jobs" />
      <div className="stage">
        <Topbar crumb={["Jobs", "Backend Intern · Kaspi.kz"]} />
        <div className="body" style={{ flexDirection: "row", overflow: "hidden" }}>

          {/* Board */}
          <div style={{ width: 460, flex: "0 0 460px", borderRight: "1px solid var(--line-soft)", display: "flex", flexDirection: "column" }}>
            <div style={{ padding: "20px 20px 12px" }}>
              <div className="eyebrow" style={{ marginBottom: 6 }}>JOBS · 86 OPEN · 12 NEW THIS WEEK</div>
              <div className="h2">Hand-picked from <i>alumni-led teams</i>.</div>
            </div>
            <div style={{ padding: "0 20px 12px", display: "flex", gap: 6, flexWrap: "wrap" }}>
              <Pill tone="blue" dot>Internship</Pill>
              <Pill>Full-time</Pill>
              <Pill>Remote ok</Pill>
              <Pill>Backend</Pill>
              <Pill>ML</Pill>
            </div>
            <div style={{ flex: 1, overflowY: "auto", padding: "0 12px 24px" }}>
              {list.map((j, i) => (
                <div key={i} style={{
                  padding: "12px 14px",
                  borderRadius: 8,
                  marginBottom: 4,
                  background: j.sel ? "var(--surface-2)" : "transparent",
                  border: "1px solid " + (j.sel ? "var(--surface-3)" : "transparent"),
                  cursor: "pointer",
                  display: "grid",
                  gridTemplateColumns: "auto 1fr auto",
                  gap: 12,
                  alignItems: "center",
                }}>
                  <div style={{ width: 36, height: 36, borderRadius: 7, background: "var(--bg-2)", border: "1px solid var(--line)", display: "grid", placeItems: "center", color: "var(--ink-2)", fontFamily: "var(--mono)", fontSize: 11 }}>
                    {j.co.slice(0, 2).toUpperCase()}
                  </div>
                  <div style={{ minWidth: 0 }}>
                    <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
                      <div className="h3" style={{ fontSize: 13 }}>{j.role}</div>
                      {j.hot && <span className="mono" style={{ fontSize: 9, color: "var(--warm)", letterSpacing: "0.06em" }}>● HOT</span>}
                    </div>
                    <div className="mute" style={{ fontSize: 11.5 }}>{j.co} · {j.loc}</div>
                    <div className="mono" style={{ fontSize: 10, color: "var(--ink-3)", marginTop: 4 }}>{j.tag} · {j.apps} apps</div>
                  </div>
                  <div style={{ textAlign: "right" }}>
                    <span className="mono mute" style={{ fontSize: 10 }}>{j.time}</span>
                    {j.status === "closing-soon" && (
                      <div className="mono" style={{ fontSize: 9, color: "var(--warm)", marginTop: 4 }}>CLOSING SOON</div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Detail */}
          <div style={{ flex: 1, minWidth: 0, overflowY: "auto" }}>
            <div style={{ padding: "28px 36px 20px", borderBottom: "1px solid var(--line-soft)" }}>
              <div style={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between", gap: 24 }}>
                <div style={{ flex: 1 }}>
                  <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 10 }}>
                    <div style={{ width: 48, height: 48, borderRadius: 10, background: "var(--bg-2)", border: "1px solid var(--line)", display: "grid", placeItems: "center", fontFamily: "var(--mono)", color: "var(--ink-2)", fontSize: 14, fontWeight: 600 }}>KS</div>
                    <div>
                      <div className="mute mono" style={{ fontSize: 10.5, letterSpacing: "0.06em" }}>KASPI.KZ · ALMATY</div>
                      <div className="h1" style={{ fontSize: 28, marginTop: 2 }}>Backend Intern, <i>summer '26</i></div>
                    </div>
                  </div>
                  <div style={{ display: "flex", flexWrap: "wrap", gap: 6, marginTop: 12 }}>
                    <Pill tone="blue" dot>Internship · 3 months</Pill>
                    <Pill>Hybrid · Almaty</Pill>
                    <Pill>₸ 350k—500k / mo</Pill>
                    <Pill tone="warm" dot>Closes May 28</Pill>
                  </div>
                </div>
                <div style={{ display: "flex", flexDirection: "column", alignItems: "flex-end", gap: 8 }}>
                  <button className="btn primary lg">Apply with profile <Icon name="arrowR" size={12} /></button>
                  <button className="btn"><Icon name="msg" size={12} /> Ask alumni</button>
                  <span className="mono mute" style={{ fontSize: 10 }}>SAVED · TRACKING</span>
                </div>
              </div>
            </div>

            {/* Match strip */}
            <div style={{ padding: "16px 36px", background: "var(--blue-soft)", borderBottom: "1px solid var(--blue-line)", display: "grid", gridTemplateColumns: "auto 1fr auto", gap: 16, alignItems: "center" }}>
              <Icon name="spark" size={16} color="var(--blue)" />
              <div>
                <div style={{ fontSize: 13, color: "var(--blue)" }}>
                  <b>92% match</b> · You meet 7 of 8 requirements. Missing: <span style={{ color: "var(--ink)" }}>Kotlin (you have Go — close enough per hiring manager).</span>
                </div>
                <div className="mono" style={{ fontSize: 10.5, color: "var(--blue)", opacity: 0.8, marginTop: 2 }}>14 AITU students hired into this role since 2022 · 3 currently active.</div>
              </div>
              <button className="btn sm">Why?</button>
            </div>

            {/* Body grid */}
            <div style={{ padding: "24px 36px 36px", display: "grid", gridTemplateColumns: "1.6fr 1fr", gap: 28 }}>
              <div>
                <div className="eyebrow" style={{ marginBottom: 10 }}>01 · ABOUT THE ROLE</div>
                <div style={{ fontSize: 13.5, lineHeight: 1.6, color: "var(--ink-2)" }}>
                  Join the payments infra team for a 3-month paid internship. You'll own a small service end-to-end — from design doc to production rollout — with weekly mentorship from a senior engineer. Past interns have shipped: idempotency keys, fraud-rule DSL, and a Kafka-based reconciliation system.
                </div>

                <div className="eyebrow" style={{ margin: "24px 0 10px" }}>02 · WHAT YOU'LL DO</div>
                <ul style={{ paddingLeft: 18, fontSize: 13, lineHeight: 1.8, color: "var(--ink-2)" }}>
                  <li>Design and ship one payments microservice</li>
                  <li>Pair with senior engineers on system design reviews</li>
                  <li>Write production code in Kotlin or Go</li>
                  <li>Operate what you build — on-call shadow rotation in week 8+</li>
                </ul>

                <div className="eyebrow" style={{ margin: "24px 0 10px" }}>03 · STACK</div>
                <div style={{ display: "flex", flexWrap: "wrap", gap: 6 }}>
                  {[
                    ["Kotlin", true], ["Go", true], ["JVM", true], ["PostgreSQL", true],
                    ["Kafka", true], ["gRPC", false], ["K8s", false], ["AWS", true],
                  ].map(([s, has]) => (
                    <span key={s} className="chip skill" style={{
                      background: has ? "var(--blue-soft)" : "var(--surface)",
                      borderColor: has ? "var(--blue-line)" : "var(--line)",
                      color: has ? "var(--blue)" : "var(--ink-2)",
                    }}>
                      {has && <Icon name="check" size={10} />} {s}
                    </span>
                  ))}
                </div>
              </div>

              <div>
                <div className="eyebrow" style={{ marginBottom: 10 }}>04 · ALUMNI INSIDE</div>
                <div className="panel" style={{ padding: 0 }}>
                  {[
                    { n: "Madiyar Toleu", t: "b3", role: "Senior SWE", note: "Will mentor interns this cycle", mentor: true },
                    { n: "Asem Nazarbek", t: "b6", role: "EM · Payments", note: "Hiring manager · open to chat" },
                    { n: "Erlan Tursyn", t: "b3", role: "SWE intern '25", note: "Now full-time · ask anything" },
                  ].map((p, i) => (
                    <div key={i} style={{ padding: "12px 14px", borderTop: i ? "1px solid var(--line-soft)" : "none", display: "grid", gridTemplateColumns: "auto 1fr auto", gap: 10, alignItems: "center" }}>
                      <Avatar name={p.n} tone={p.t} size="s" />
                      <div style={{ minWidth: 0 }}>
                        <div className="h3" style={{ fontSize: 12.5 }}>{p.n} {p.mentor && <Pill tone="blue" dot>mentor</Pill>}</div>
                        <div className="mute mono" style={{ fontSize: 10 }}>{p.role}</div>
                        <div style={{ fontSize: 11, color: "var(--ink-2)", marginTop: 2 }}>{p.note}</div>
                      </div>
                      <button className="btn sm">DM</button>
                    </div>
                  ))}
                </div>

                <div className="eyebrow" style={{ margin: "24px 0 10px" }}>05 · YOUR APPLICATION</div>
                <div className="panel" style={{ padding: 14 }}>
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 10 }}>
                    <span className="mono" style={{ fontSize: 11, color: "var(--ink-2)" }}>STATUS</span>
                    <Pill>Not submitted</Pill>
                  </div>
                  <div className="divider" style={{ margin: "8px 0 12px" }}></div>
                  <div style={{ fontSize: 12, color: "var(--ink-2)", marginBottom: 10 }}>
                    Profile auto-fills 4 of 5 fields. You'll only add a cover letter.
                  </div>
                  <Placeholder label="cover letter · 240 char draft" height={64} mono />
                  <button className="btn primary" style={{ marginTop: 10, width: "100%", justifyContent: "center" }}>Continue application</button>
                </div>

                <div className="eyebrow" style={{ margin: "24px 0 10px" }}>06 · APPLICATION PIPELINE</div>
                <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
                  {[
                    ["Submitted", "—", false],
                    ["Viewed", "avg 3d", false],
                    ["Shortlisted", "32% rate", false],
                    ["Interview", "1—2 rounds", false],
                    ["Offer", "—", false],
                  ].map(([k, v], i) => (
                    <div key={i} style={{ display: "grid", gridTemplateColumns: "16px 1fr auto", gap: 10, alignItems: "center", fontSize: 11.5 }}>
                      <span style={{ width: 10, height: 10, borderRadius: "50%", border: "1.5px solid var(--ink-4)" }} />
                      <span style={{ color: "var(--ink-2)" }}>{k}</span>
                      <span className="mono mute" style={{ fontSize: 10 }}>{v}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
window.Jobs = Jobs;
