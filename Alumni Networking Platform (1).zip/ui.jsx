// Shared primitives + side rail + AITU mark
const { useState, useMemo } = React;

// AITU concentric arcs glyph (original geometric reinterpretation)
function AituGlyph({ size = 32, color = "currentColor", accent = "#4ba6dc" }) {
  // 4 dotted arcs around a solid disc — mirrors the spirit of the AITU mark
  // without copying its proportions or asset.
  const cx = size / 2, cy = size / 2;
  const arcs = [
    { r: size * 0.18, dots: 10, color, sweep: 360, start: 0 },
    { r: size * 0.30, dots: 14, color, sweep: 270, start: 200 },
    { r: size * 0.42, dots: 18, color: accent, sweep: 240, start: 230 },
    { r: size * 0.54, dots: 24, color, sweep: 200, start: 240 },
  ];
  const dots = [];
  arcs.forEach((a, ai) => {
    for (let i = 0; i < a.dots; i++) {
      const t = a.start + (a.sweep / a.dots) * i;
      const rad = (t * Math.PI) / 180;
      dots.push(
        <circle
          key={`${ai}-${i}`}
          cx={cx + Math.cos(rad) * a.r}
          cy={cy + Math.sin(rad) * a.r}
          r={Math.max(0.7, size * 0.022)}
          fill={a.color}
          opacity={0.85}
        />
      );
    }
  });
  return (
    <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`}>
      {dots}
      <circle cx={cx} cy={cy} r={size * 0.10} fill={color} />
    </svg>
  );
}

// Icons (stroke, 1.5)
const I = {
  home: <path d="M3 11l9-7 9 7v9a1 1 0 0 1-1 1h-5v-7H9v7H4a1 1 0 0 1-1-1z"/>,
  user: <><circle cx="12" cy="8" r="4"/><path d="M4 21c0-4.4 3.6-8 8-8s8 3.6 8 8"/></>,
  users: <><circle cx="9" cy="8" r="3.5"/><circle cx="17" cy="9" r="3"/><path d="M3 20c0-3.3 2.7-6 6-6s6 2.7 6 6"/><path d="M14 20c0-2.4 1.5-4.5 3.5-5.4"/></>,
  graph: <><path d="M4 20V8M10 20v-6M16 20V4M22 20H2"/></>,
  jobs: <><rect x="3" y="6" width="18" height="14" rx="2"/><path d="M9 6V4a2 2 0 0 1 2-2h2a2 2 0 0 1 2 2v2"/><path d="M3 12h18"/></>,
  cal: <><rect x="3" y="5" width="18" height="16" rx="2"/><path d="M3 9h18M8 3v4M16 3v4"/></>,
  msg: <path d="M21 12a8 8 0 0 1-12 7l-5 1 1-4a8 8 0 1 1 16-4z"/>,
  bell: <><path d="M6 8a6 6 0 1 1 12 0c0 7 3 7 3 9H3c0-2 3-2 3-9z"/><path d="M10 21a2 2 0 0 0 4 0"/></>,
  spark: <><path d="M12 3l1.8 5.4L19 10l-5.2 1.6L12 17l-1.8-5.4L5 10l5.2-1.6z"/><path d="M19 4l.6 1.8L21 6.4l-1.4.6L19 9l-.6-1.8L17 6.4l1.4-.6z"/></>,
  doc: <><path d="M14 3H6a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9z"/><path d="M14 3v6h6M8 14h8M8 18h6"/></>,
  search: <><circle cx="11" cy="11" r="7"/><path d="M21 21l-4.5-4.5"/></>,
  plus: <><path d="M12 5v14M5 12h14"/></>,
  arrowR: <><path d="M5 12h14M13 6l6 6-6 6"/></>,
  arrowU: <><path d="M12 19V5M6 11l6-6 6 6"/></>,
  arrowD: <><path d="M12 5v14M6 13l6 6 6-6"/></>,
  filter: <path d="M4 5h16l-6 8v6l-4-2v-4z"/>,
  send: <><path d="M22 2L11 13M22 2l-7 20-4-9-9-4z"/></>,
  paper: <path d="M15 5l4 4-9 9-4 1 1-4 8-10z"/>,
  check: <path d="M5 12l5 5L20 7"/>,
  close: <><path d="M6 6l12 12M18 6l-12 12"/></>,
  more: <><circle cx="5" cy="12" r="1.5"/><circle cx="12" cy="12" r="1.5"/><circle cx="19" cy="12" r="1.5"/></>,
  upload: <><path d="M12 16V4M6 10l6-6 6 6"/><path d="M4 16v3a1 1 0 0 0 1 1h14a1 1 0 0 0 1-1v-3"/></>,
  link: <><path d="M10 14a4 4 0 0 0 5.7 0l3-3a4 4 0 1 0-5.7-5.7l-1.5 1.5"/><path d="M14 10a4 4 0 0 0-5.7 0l-3 3a4 4 0 0 0 5.7 5.7l1.5-1.5"/></>,
  pin: <><path d="M12 2v8a4 4 0 0 1 4 4H8a4 4 0 0 1 4-4z"/><path d="M12 14v8M9 22h6"/></>,
  sliders: <><path d="M4 6h12M4 12h6M4 18h16"/><circle cx="18" cy="6" r="2"/><circle cx="13" cy="12" r="2"/><circle cx="9" cy="18" r="2"/></>,
  briefcase: <><rect x="3" y="7" width="18" height="13" rx="2"/><path d="M9 7V5a2 2 0 0 1 2-2h2a2 2 0 0 1 2 2v2"/></>,
  dot3: <><circle cx="6" cy="12" r="1.5"/><circle cx="12" cy="12" r="1.5"/><circle cx="18" cy="12" r="1.5"/></>,
  external: <><path d="M14 4h6v6"/><path d="M10 14L20 4"/><path d="M20 14v5a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V5a1 1 0 0 1 1-1h5"/></>,
};
function Icon({ name, size = 18, ...rest }) {
  return (
    <svg viewBox="0 0 24 24" width={size} height={size} fill="none"
         stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"
         strokeLinejoin="round" {...rest}>
      {I[name]}
    </svg>
  );
}

function Pill({ children, tone, dot = false }) {
  return (
    <span className={`pill${tone ? " " + tone : ""}`}>
      {dot && <span className="dot" />}
      {children}
    </span>
  );
}

function Avatar({ name, size = "m", tone = "b1", monogram }) {
  const initials = monogram || (name || "")
    .split(/\s+/)
    .filter(Boolean)
    .slice(0, 2)
    .map(w => w[0])
    .join("")
    .toUpperCase();
  return <div className={`avatar ${size} ${tone}`}>{initials}</div>;
}

// Side rail with active state passed in
function Rail({ active = "home" }) {
  const items = [
    { id: "home", icon: "home", label: "Dashboard" },
    { id: "directory", icon: "users", label: "Directory" },
    { id: "mentor", icon: "graph", label: "Mentorship" },
    { id: "jobs", icon: "briefcase", label: "Jobs" },
    { id: "events", icon: "cal", label: "Events" },
    { id: "msg", icon: "msg", label: "Messages" },
    { id: "ai", icon: "spark", label: "AqyldyAI" },
  ];
  return (
    <div className="rail">
      <div className="rail-mark" title="AITU">
        <AituGlyph size={20} color="#0c0e10" accent="#2b7bb8" />
      </div>
      {items.map(it => (
        <div key={it.id}
             className={`rail-btn${active === it.id ? " active" : ""}`}
             title={it.label}>
          <Icon name={it.icon} />
        </div>
      ))}
      <div className="rail-spacer" />
      <div className="rail-divider" />
      <div className="rail-btn" title="Notifications">
        <Icon name="bell" />
      </div>
      <div className="rail-avatar">AK</div>
    </div>
  );
}

function Topbar({ crumb, search, action }) {
  return (
    <div className="topbar">
      <div className="crumb">
        {crumb.map((c, i) => (
          <React.Fragment key={i}>
            {i > 0 && <span className="sep">/</span>}
            <span className={i === crumb.length - 1 ? "" : ""}>
              {i === crumb.length - 1 ? <b>{c}</b> : c}
            </span>
          </React.Fragment>
        ))}
      </div>
      <div className="topbar-search">
        <Icon name="search" size={13} />
        <span>{search || "Search alumni, jobs, events…"}</span>
        <kbd>⌘K</kbd>
      </div>
      <div className="topbar-actions">
        <button className="iconbtn"><Icon name="bell" /><span className="dot" /></button>
        <button className="iconbtn"><Icon name="msg" /></button>
        {action}
      </div>
    </div>
  );
}

// Big number caption (01, 02…)
function NumCap({ n }) {
  return <span className="numcap">{String(n).padStart(2, "0")}</span>;
}

// Striped placeholder block (for cover images, document previews etc.)
function Placeholder({ label, height = 120, mono = true, tone = "warm" }) {
  return (
    <div
      style={{
        height,
        borderRadius: 8,
        border: "1px solid var(--line)",
        background:
          tone === "warm"
            ? "repeating-linear-gradient(-45deg, rgba(216,165,116,.08) 0 8px, transparent 8px 16px), var(--bg-2)"
            : "repeating-linear-gradient(-45deg, rgba(75,166,220,.08) 0 8px, transparent 8px 16px), var(--bg-2)",
        display: "grid",
        placeItems: "center",
        color: "var(--ink-3)",
        fontFamily: mono ? "var(--mono)" : "var(--sans)",
        fontSize: 10.5,
        letterSpacing: "0.08em",
        textTransform: "uppercase",
      }}
    >
      {label}
    </div>
  );
}

Object.assign(window, {
  AituGlyph, Icon, Pill, Avatar, Rail, Topbar, NumCap, Placeholder,
});
